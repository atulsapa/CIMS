package CIMS.Modules.Regression;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import listner.ErrorUtil;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.ITestResult;
import org.testng.Reporter;

import util.UtilFunction;

public class CIMS_GCP_NewQuery
{
	
	private WebDriver webdriver;	// Will be Provide by Calling Class.	
	private UtilFunction utilfunc;	// Will be Provide by Calling Class.	
	private Robot Robot;
	//Variables-------------
	

	 

	
	
	 
	// GCP Xpath
	public static String testcaseid="";
	public static String scenerio="";
	public static String description="";
	
	 private static String GCPNewQueryTitleXpath="//*[@id='panel-header']";
	 private static String GCPNewQueryCountryXpath=".//*[@id='CompanyList']";	 
	 private static String CounterGCPTravelerFileds=".//*[@class='form-horizontal']//*[@class='control-group']//*[@name]";	 
	 private static String GCPFieldXpath=".//*[@class='form-horizontal']//*[@class='control-group']//input[xx]";
	 
	 private static String GCPFirstNameXpath=".//*[@class='controls']//*[@class='control-group'][1]//input";	 
	 private static String GCPLastNameXpath=".//*[@class='controls']//*[@class='control-group'][2]//input";
	 
	 private static String GCPEmailXpath=".//*[@id='txtEmail']";
	 private static String GCPEmployeeIDXpath=".//*[@id='txtEmployeeNumber']";
	 
	 private static String GCPNationalityCountryXpath=".//*[@id='Nationality']";
	 
	 private static String GCPAddButtonXpath=".//*[@id='btnAddNationality']";
	 
	 private static String GCPSPecialVisaXpath=".//*[@id='SpecialConditionCountry']";
	 private static String GCPSPecialVisaPermitXpath=".//*[@id='SpecialCondition']";
	 
	 private static String GCPDestinationButtontXpath=".//*[@id='new-destination-trigger']";
	 private static String GCPDestinationOriginCountryCodeXpath=".//*[@id='form_OriginCountryCode']";
	 private static String GCPDestinationCountryCodeXpath=".//*[@id='form_DestinationCountryCode']";
	 private static String GCPDestinationCityXpath=".//*[@id='form_DestinationCity']";
	 private static String GCPDestinationPurposeIdXpath=".//*[@id='form_PurposeId']";
	 private static String GCPDestinationAddPurposeButtonXpath=".//*[@id='btnAddPurpose']";
	 private static String GCPDestinationDateOfArrivalXpath=".//*[@id='form_DateOfArrival']";
	 private static String GCPDestinationDateOfDepartureXpath=".//*[@id='form_DateOfDeparture']";
	 private static String GCPDestinationAddDestButtonXpath=".//*[@id='btnAddDest']";
	 
	 
	 private static String GCPFinishDestButtonXpath=".//*[@id='btnSave']";
	 //Constructor----------
	 
		public CIMS_GCP_NewQuery(WebDriver driver,UtilFunction utilfunc) 
		{
		this.webdriver =driver;
		this.utilfunc=utilfunc;
		
		// TODO Auto-generated constructor stub
		}
		
		//Functions--------------
		/**
		 * Verify that User is able to logged in successfully 
		 * 	
		 * @throws AWTException
		 * @throws InterruptedException
		 */
		
	 
	public boolean  GCP_NewQuery_Initiation_Page(String filename, String sheetName,int ColumnCounter,String mode) throws AWTException, InterruptedException{

		//Excel sheet Data collection
	
		 boolean GCP_NewQuery_Initiation_Page_flag=false;
		 
		String TestcaseID									=			UtilFunction.getCellData(filename, sheetName, 0, ColumnCounter);
		String TestcaseRunMode								=			UtilFunction.getCellData(filename, sheetName, 1, ColumnCounter);
		String Scenario										=			UtilFunction.getCellData(filename, sheetName, 2, ColumnCounter);
		String TestCaseDescription							=			UtilFunction.getCellData(filename, sheetName, 3, ColumnCounter);
		 String GCPDestinationcountry	=UtilFunction.getCellData(filename, sheetName, 4, ColumnCounter);
		 String GCPFirstName=UtilFunction.getCellData(filename, sheetName, 5, ColumnCounter);
		 String GCPLastName=UtilFunction.getCellData(filename, sheetName, 6, ColumnCounter);
		
		 String GCPEmail=UtilFunction.getCellData(filename, sheetName, 7, ColumnCounter);
		 String GCPEmployeeID=UtilFunction.getCellData(filename, sheetName, 8, ColumnCounter);
		 String GCPNationalityCountry=UtilFunction.getCellData(filename, sheetName, 9, ColumnCounter);
		 
		 String GCPSPecialVisa=UtilFunction.getCellData(filename, sheetName, 10, ColumnCounter);
		 String GCPSPecialVisaPermit=UtilFunction.getCellData(filename, sheetName, 11, ColumnCounter);
		 
		 String GCPDestinationOriginCountryCode=UtilFunction.getCellData(filename, sheetName, 12, ColumnCounter);
		 String GCPDestinationCountryCode=UtilFunction.getCellData(filename, sheetName, 13, ColumnCounter);
		 
		 String GCPDestinationCity=UtilFunction.getCellData(filename, sheetName, 14, ColumnCounter);
		 //String GCPDestinationPurposeId=UtilFunction.getCellData(filename, "Globalchek Plus", 15, ColumnCounter);
		 
		 String GCPDestinationDateOfArrival=UtilFunction.getCellData(filename, sheetName, 15, ColumnCounter);
		 String GCPDestinationDateOfDeparture=UtilFunction.getCellData(filename, sheetName, 16, ColumnCounter);
		
		
		 
		 if(TestcaseRunMode.equals("Y")){ 
		 testcaseid		=		TestcaseID;
			scenerio		=		Scenario;
			description		=		TestCaseDescription;


		Actions act= new Actions(webdriver);
		
		
		Robot robot = new Robot();
		
		 String GCPHeaderTitle=utilfunc.MakeElement(GCPNewQueryTitleXpath).getText();	
		try{
		 if (GCPHeaderTitle.equalsIgnoreCase(GCPHeaderTitle)){
			 
			 // Traveler Details
			 utilfunc.Selectdropdownvaluebyvalue(GCPNewQueryCountryXpath, GCPDestinationcountry);
			 utilfunc.MakeElement(GCPFirstNameXpath).clear();
			 utilfunc.MakeElement(GCPFirstNameXpath).sendKeys(GCPFirstName);
			 
			 utilfunc.MakeElement(GCPLastNameXpath).clear();
			 utilfunc.MakeElement(GCPLastNameXpath).sendKeys(GCPLastName);
			 
			 utilfunc.MakeElement(GCPEmailXpath).clear();
			 utilfunc.MakeElement(GCPEmailXpath).sendKeys(GCPEmail);
			 
			 utilfunc.MakeElement(GCPEmployeeIDXpath).clear();
			 utilfunc.MakeElement(GCPEmployeeIDXpath).sendKeys(GCPEmployeeID);
			 

			 utilfunc.Selectdropdownvaluebyvalue(GCPNationalityCountryXpath, GCPNationalityCountry);
			/* robot.keyPress(KeyEvent.VK_ENTER);
			 robot.keyRelease(KeyEvent.VK_ENTER);*/
		
			 Thread.sleep(1000);
			 utilfunc.MakeElement(GCPEmailXpath).click();
			 utilfunc.MakeElement(GCPAddButtonXpath).click();
			 Thread.sleep(1000);
						 
			 utilfunc.Selectdropdownvaluebyvalue(GCPSPecialVisaXpath, GCPSPecialVisa);
			 utilfunc.Selectdropdownvaluebyvalue(GCPSPecialVisaPermitXpath, GCPSPecialVisaPermit);

			
			 //Destination List
			 utilfunc.MakeElement(GCPDestinationButtontXpath).click();
			 Thread.sleep(1000);
			 utilfunc.Selectdropdownvaluebyvalue(GCPDestinationOriginCountryCodeXpath, GCPDestinationOriginCountryCode);
			 utilfunc.MakeElement(GCPEmailXpath).click();
			 utilfunc.Selectdropdownvaluebyvalue(GCPDestinationCountryCodeXpath, GCPDestinationCountryCode);
			 utilfunc.MakeElement(GCPDestinationCityXpath).sendKeys(GCPDestinationCity);
			 
			 utilfunc.MakeElement(GCPDestinationPurposeIdXpath).click();
			 robot.keyPress(KeyEvent.VK_DOWN);
			 robot.keyRelease(KeyEvent.VK_DOWN);
			 
			 robot.keyPress(KeyEvent.VK_ENTER);
			 robot.keyRelease(KeyEvent.VK_ENTER);
			 utilfunc.MakeElement(GCPEmailXpath).click();
			 utilfunc.MakeElement(GCPDestinationAddPurposeButtonXpath).click();
			 Thread.sleep(1000);
			 utilfunc.MakeElement(GCPDestinationDateOfArrivalXpath).sendKeys(GCPDestinationDateOfArrival);
			 utilfunc.MakeElement(GCPDestinationDateOfDepartureXpath).sendKeys(GCPDestinationDateOfDeparture);
			 
			 //Destination Add Click
			 utilfunc.MakeElement(GCPDestinationAddDestButtonXpath).click();
		
			 Thread.sleep(2000);
			 
			 utilfunc.MakeElement(GCPFinishDestButtonXpath).click();
			 Thread.sleep(6000);
			 
		 	}
		 
		 	else { 
			 System.out.println("User Landed on Different Page");
		 	}
		}
		catch(Exception e){
			
		} 
		 }
		return GCP_NewQuery_Initiation_Page_flag;

	 }
	 

	 
}