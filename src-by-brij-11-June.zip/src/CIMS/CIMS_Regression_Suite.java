package CIMS;


import java.awt.AWTException;
import java.awt.List;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.time.StopWatch;

import listner.ErrorUtil;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.sun.jna.platform.win32.WinUser.FLASHWINFO;
import com.sun.rmi.rmid.ExecPermission;
import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;
import com.sun.xml.internal.ws.api.pipe.NextAction;
import com.thoughtworks.selenium.Wait;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;







//import util.Email;
import util.RunMode;
import util.UtilFunction;
import CIMS.Modules.Questionnaires.CIMS_Login;
import CIMS.Modules.Questionnaires.Project_Initiation;
import CIMS.Modules.Advanced.*;
import CIMS.Modules.Regression.*; 
import CIMS.Reports.*;



@SuppressWarnings("deprecation")
public class CIMS_Regression_Suite {

	private String 										sysDate;
	private WebDriver 									webdriver;		
	private UtilFunction 								utilfunc;		
	private CIMS_Login 									obj_CIMS_Login;

	private Employee_Search								obj_Employee_Search;

	private Project_Initiation 							obj_Project_Initiation;

	private CIMS_Single_Project_Initiation 				obj_CIMS_Single_Project_Initiation;
	private CIMS_Regresssion_Suite_Bulk_Initiation 		obj_CIMS_Regresssion_Suite_Bulk_Initiation;
	private CIMS_Regression_Suite_Immigration_Status   	obj_CIMS_Regression_Suite_Immigration_Status;
	private CIMS_Immigration_Document                   obj_CIMS_Immigration_Document;
	private CIMS_Regression_Suite_Employee_Profile		obj_CIMS_Regression_Suite_Employee_Profile;
	private CIMS_GCP_NewQuery							obj_CIMS_GCP_NewQuery;
	private Project_Search								obj_Project_Search;

	private dashboard 									obj_Report_Dashboard;
	//Lokesh append this code for "ALL MY TASKS" on welcome page
	//private CIMS_Regression_Suite_AllMyTasks			obj_CIMS_Regression_Suite_AllMyTasks; 
	//Lokesh append this code for "NEWS" on welcome page
	private CIMS_Regression_Suite_News			obj_CIMS_Regression_Suite_News;

	private CIMS_Secure_Messaging      obj_CIMS_Secure_Messaging;

	private CIMS_Regression_Suite_Process_Questionnaire_Assignment obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment;
	private CIMS_Processandquestionnaire_ProcessType         obj_CIMS_Processandquestionnaire_ProcessType;
	private CIMS_Regression_Suite_Emp_Questionnaire_Assignment obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment;
	private CIMS_Regression_ProcessAndQuestionnaire_contact obj_CIMS_Regression_ProcessAndQuestionnaire_contact;



	//file name that takes dynamically in all modules.
	public static String ExcelFileName="Test Regression Suite Data.xls";
	public String sheetName="URLANDNAME";
	public static String os=System.getProperty("os.name");
	public static String osbit=System.getProperty("sun.arch.data.model");
	public static String moduleName="";
	public static String Employee_namecheck=null;
	public static String questionarie_name1="";
	public static String timer;
	private String columnNameRM="RUNMODE";
	private String columnNameAction="ACTION";


	public static String SelectQuestionnairetype	=		"";

	public static String Questionnaire_Name_array[]=new String [100];

	static int instanceCounter = 0;
	static int instanceCounter1 = 0;
	static int counter1 = 0;


	//timer
	StopWatch pageLoad = new StopWatch();


	//Initiate the class Before TEST method

	@BeforeClass
	public void isSkipped(){

		if(RunMode.isSkip(ExcelFileName,this.getClass().getName())){
			Reporter.log("");
			Reporter.log(this.getClass().getName()+" Test is Skipped Intentionally.");
			Reporter.log("");
			Reporter.log("This Test will be Skipped as Run Mode is set 'No' in the Test Data Excel Sheet.");
			throw new SkipException("Test will be Skiped as Run Mode is Set to 'N' in Test Data xls File.");
		}
		else {	

			//				System.out.println("browser:  "+UtilFunction.getBrowser(this.getClass().getName()));
			setDriver(UtilFunction.getBrowser(this.getClass().getName(),this.ExcelFileName));
			setSysDate(UtilFunction.currentDateTime());				
			setUtilfunc(new UtilFunction(this.getDriver()));	
			setobj_CIMS_Login(new CIMS_Login(webdriver, utilfunc));
			setobj_dashboard((new dashboard()));

			setobj_CIMS_Single_Project_Initiation(new CIMS_Single_Project_Initiation (webdriver,utilfunc));
			setobj_CIMS_Regresssion_Suite_Bulk_Initiation(new CIMS_Regresssion_Suite_Bulk_Initiation (webdriver,utilfunc));


			// Lokesh add these line(s) on 06-May-2016 for Advance Project search
			setobj_Project_Search(new Project_Search(webdriver,utilfunc));

			setobj_CIMS_Secure_Messaging(new CIMS_Secure_Messaging (webdriver,utilfunc));
			

			/**
			 * code added by Brij, starts here
			 */

			setobj_Project_Initiation(new Project_Initiation (webdriver,utilfunc));
			setobj_CIMS_Regression_Suite_Immigration_Status(new CIMS_Regression_Suite_Immigration_Status(webdriver, utilfunc));
			setobj_CIMS_Immigration_Document(new CIMS_Immigration_Document(webdriver, utilfunc));
			setobj_CIMS_Regression_Suite_Employee_Profile(new CIMS_Regression_Suite_Employee_Profile(webdriver, utilfunc));
			setobj_CIMS_GCP_NewQuery(new CIMS_GCP_NewQuery(webdriver, utilfunc));
			//Lokesh Append this code for "All My Tasks" Module
			//		setobj_CIMS_Regression_Suite_AllMyTasks(new CIMS_Regression_Suite_AllMyTasks(webdriver,utilfunc));
			//Lokesh Append this code for "News" Module
			setobj_CIMS_Regression_Suite_News(new CIMS_Regression_Suite_News(webdriver,utilfunc));
			
			setobj_CIMS_Regression_Suite_Process_Questionnaire_Assignment(new CIMS_Regression_Suite_Process_Questionnaire_Assignment(webdriver,utilfunc));
			setobj_CIMS_Processandquestionnaire_ProcessType(new CIMS_Processandquestionnaire_ProcessType(webdriver,utilfunc));
			setobj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment(new CIMS_Regression_Suite_Emp_Questionnaire_Assignment(webdriver,utilfunc));
			setobj_CIMS_Regression_ProcessAndQuestionnaire_contact(new CIMS_Regression_ProcessAndQuestionnaire_contact(webdriver,utilfunc));
			

			setobj_Employee_Search(new Employee_Search(webdriver,utilfunc));

			/**
			 * code added by Brij, ends here   
			 */


			if(UtilFunction.Actualbrw.equals("IE")){
				webdriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

			}else if(UtilFunction.Actualbrw.equals("CHROME")){
				webdriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

			}else{
				webdriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

			}
			Reporter.log("");
			Reporter.log("***************************Opening the Application*********************************");

			boolean StartApplicationFlag = utilfunc.startApplication(ExcelFileName);
			if(!StartApplicationFlag){
				Reporter.log("User is not able to Open the application");
			}
			else {
				Reporter.log("Opened the Application URL Successfully");
			}
		}
	}




	@AfterMethod
	public void closeBrowser() {
		Reporter.log("Closing Opened Browser");
		boolean CloaseBrowserFlag = utilfunc.closeWebDriver();		
		if(!CloaseBrowserFlag){
			Reporter.log("User is not able to close the application");
		}
		else {
			Reporter.log("Closed the application.");
		}

	}



	//Our Test start from here.

	@Test

	public void CIMSSingleProjectInitiation() throws InterruptedException, IOException, AWTException {


		try {
			/*p = System.getProperty("os.name");
		System.out.println("Operating system is"+p);*/

			// Project  Login	
			obj_CIMS_Login.Project_login();

			//Welcome page
			obj_CIMS_Login.Welcome_Page();


			//privacy disclaimer check
			try{

				String check=".//*[@id='chkConfirm']";
				String Agreebutton=".//*[@id='btnNext']";

				utilfunc.MakeElement(check).click();                               
				utilfunc.MakeElement(Agreebutton).click();

			}catch(Exception e){
				System.out.println("Privacy policy Disclaimer is not Exist on the Page");
			}

			// let us zoom out 2-3 times of current screen so that slider icon is never missed out while switching any module

			utilfunc.zoomOut(3);

			//Getting employee Name
			try{
				utilfunc.MakeElement("//*[@id='user-profile']").click();
				Employee_namecheck				=	utilfunc.MakeElement(".//*[@id='user-name']").getText();
				Thread.sleep(400);
				utilfunc.MakeElement("//*[@id='user-profile']").click();
				System.out.println(Employee_namecheck);
			}catch(Exception e){
				System.out.println("Unable to find Employee name and using username instead");	
			}

			/**
			 * code for regression suite starts here
			 * @author Brij
			 */

			//initialize variables that will be used..

			boolean visitSPILink					=	false;
			boolean	openSuite						=	false;
			boolean Page_flag						=	false;
			String fileName							=	ExcelFileName;
			String suiteLink						=	"";
			String status							=	"";
			long startTime							=	0;
			String MenuLink								=	"";
			boolean employeeSearchFlag				=	false;
			String IdentifyIE						=	"";
			String []	EmpDependantSuiteName		=	{"Immigration Status","Employee Profile","Document","ProcessQuestionnaire Assignment"};
			long startTotalTime						=	0;
			String TotalTime						=	"";

			//Lokesh add these lines for get count of +ve and -ve test cases.
			int PositiveScenarioCounter				=	0;
			int NegativeScenarioCounter				=	0;
			int ModuleCounter						=	0;
			int TotalTestCaseCounter				=	0;
			int passTestCaseCounter					=	0;
			int failTestCaseCounter					=	0;
			int NotAssignedModuleCounter			=	0;
			
			//for Old SPI
			int OldSPI_PositiveScenarioCounter				=	0;
			int OldSPI_NegativeScenarioCounter				=	0;
			int OldSPI_ModuleCounter						=	1;
			int OldSPI_TotalTestCaseCounter					=	0;
			int OldSPI_passTestCaseCounter					=	0;
			int OldSPI_failTestCaseCounter					=	0;
			int OldSPI_NotAssignedModuleCounter			=	0;
			
			ArrayList NumberOfNotAssignModule = new ArrayList();

			// let us choose Regrssion suites from excel with Run mode Yes 
			String 	RegressionSuites				=		"Regression Suites";
			int RowCount							=		UtilFunction.usedRowCount(fileName, RegressionSuites);
			int columnNumber_RUNMODE				=		UtilFunction.getColumnWithCellData(fileName, RegressionSuites, columnNameRM);
			int columnNumber_ACTION					=		UtilFunction.getColumnWithCellData(fileName, RegressionSuites, columnNameAction);
			int columnNumber_SuiteName				=		UtilFunction.getColumnWithCellData(fileName, RegressionSuites, "Suite Name");


			startTotalTime = System.currentTimeMillis();
			// loop running for regression suites
			for(int modCounter = 1;modCounter<RowCount;modCounter++){

				try{
					
					boolean passCounter	=	false;
					boolean failCounter	=	false;
					boolean notAssignedCounter	=	false;
					
					// check if current suite name is set to runmode Y..
					if(UtilFunction.getCellData(fileName, RegressionSuites, columnNumber_RUNMODE, modCounter).equals("Y")){
						ModuleCounter=ModuleCounter+1;
						// now pick the name of regression suite, action, etc that is set to runmode Y

						String SuiteName				=		UtilFunction.getCellData(fileName, RegressionSuites, columnNumber_SuiteName, modCounter);
						String ActionName				=		UtilFunction.getCellData(fileName, RegressionSuites, columnNumber_ACTION, modCounter);


						System.out.println("Sheet selected to pull data is: "	+ SuiteName	+	" and with Action: "	+	ActionName);

						// let uss search for employee for modules like Immigration status, document, profile.. etc
						if(Arrays.asList(EmpDependantSuiteName).contains(SuiteName)){

							String empSheetName				=		"Employee Profile";
							String Employee_search			=		"";

							int rowCountemployeesearch		=		UtilFunction.usedRowCount(fileName,empSheetName);
							int RUNMODEemployeesearch		=		UtilFunction.getColumnWithCellData(fileName, empSheetName, "RUNMODE");
							String columnNameEN				=		"EMPLOYEE NAME";
							int Employee_name				=		UtilFunction.getColumnWithCellData(fileName, empSheetName, columnNameEN);
							String columnNameES				=		"EMPLOYEE Reference Number";
							int Employee_search_name		=		UtilFunction.getColumnWithCellData(fileName, empSheetName, columnNameES);
							String columnNameSQT			=		"QUESTIONNAIRE TYPE";
							int Questionnairetype			=		UtilFunction.getColumnWithCellData(fileName, empSheetName, columnNameSQT);


							for(int j = 1;j<rowCountemployeesearch;j++){

								if(UtilFunction.getCellData(fileName, empSheetName, RUNMODEemployeesearch,j).equals("Y") && employeeSearchFlag==false){



									System.out.println("second loop ran for "+j+" time");

									try{
										Thread.sleep(3000);
										Employee_namecheck			=			UtilFunction.getCellData(fileName, empSheetName, Employee_name, j);
										Employee_search				=			UtilFunction.getCellData(fileName, empSheetName, Employee_search_name, j);
										SelectQuestionnairetype		=			UtilFunction.getCellData(fileName, empSheetName, Questionnairetype, j);

										try {
											obj_CIMS_Login.searchemployee(Employee_namecheck, Employee_search);
											/*System.out.println("current url"+utilfunc.getPageUrl());
									if(utilfunc.getPageUrl().contains("Profile")){
										employeeSearchFlag	=	true;
									}*/
										} catch (Exception e) {
											// TODO: handle exception
										}

									}catch(Exception e){
										System.out.println("employee search falied.."+ e);
									}
								}
							}				
							// code for employee profile
							if(SuiteName.equals("Employee Profile")){
								// lets click on profile button and run all modules that are enabled for profile
								try{
									if(SelectQuestionnairetype.equals("PROFILE")){
										//modification
										String sidebarxpath=".//*[@id='slider-icon']";
										utilfunc.MakeElement(sidebarxpath).click();
										Thread.sleep(3000);

										String Principalheaderxpath=".//*[@id='rnav-principal-header']//a";
										utilfunc.MakeElement(Principalheaderxpath).click();
										Thread.sleep(3000);

										String Basicinfoxpath=".//*[@id='sectBasicInformation']//a";
										utilfunc.MakeElement(Basicinfoxpath).click();
										Thread.sleep(3000);
									}
								}catch(Exception e){
									System.out.println("unable to click on slider icon...");
								}

								// call all profile modules..'

								String sheetName				=	"Questionnaires";
								String ExcelSheetname			=	"Test Data.xls";
								int rowCount					=	UtilFunction.usedRowCount(ExcelSheetname,sheetName);
								int columnNumber_emp_RUNMODE	=	UtilFunction.getColumnWithCellData(ExcelSheetname, sheetName, columnNameRM);
								int columnNumber_emp_ACTION		=	UtilFunction.getColumnWithCellData(ExcelSheetname, sheetName, columnNameAction);

								//questionnaire label
								String columnName1="Questionnaire Name";
								int questionnarie_name=UtilFunction.getColumnWithCellData(ExcelSheetname, sheetName, columnName1);
								for(int in=1;in<=rowCount;in++){
									int counter=0;
									//Below condition is used to check the RUNMODE for the Questionnaire modules
									if(UtilFunction.getCellData(ExcelSheetname, sheetName, columnNumber_emp_RUNMODE, in).equals("Y")){

										//Questionnaire action mode(New,Edit, Delete)
										String QUESTIONNAIR_ACTION				=		UtilFunction.getCellData(ExcelSheetname, sheetName, columnNumber_emp_ACTION, in);

										//Questionnaire module name 
										String questionnarie_name1				=		UtilFunction.getCellData(ExcelSheetname, sheetName, questionnarie_name, in);

										//		    					String sheetName1						=		questionnarie_name1;		
										//		    					String column_ques_Name						=		"RUNMODE";
										//String columnName5="ACTION";
										int columnNumber_RUNMODE1	=	UtilFunction.getColumnWithCellData(ExcelSheetname, questionnarie_name1, columnNameRM);
										int rowCount1	=	UtilFunction.usedRowCount(ExcelSheetname,questionnarie_name1);

										try{
											Thread.sleep(2500);
											obj_CIMS_Regression_Suite_Employee_Profile.Employee_Profile(questionnarie_name1, QUESTIONNAIR_ACTION, ExcelSheetname, questionnarie_name1, columnNumber_RUNMODE1, rowCount1, Employee_namecheck, SuiteName);
										}catch(Exception e){ 
											System.out.println("unable to process employee profile");
										}
									}

								}

							}

						}


						// now check module run modes with Y.. and call module objects..

						String sheetName					=	SuiteName;
						int rowCount						=	UtilFunction.usedRowCount(fileName,sheetName);
						int columnNumber_suiteNm_RUNMODE	=	UtilFunction.getColumnWithCellData(fileName, sheetName, columnNameRM);
						int Scenariocol=0;
						if(sheetName.equalsIgnoreCase("old Initiation"))
						{
							Scenariocol	=	UtilFunction.getColumnWithCellData("Test Data.xls", "Project Initiation", "SCENARIO");
						}
						else{
						Scenariocol	=	UtilFunction.getColumnWithCellData(fileName, sheetName, "SCENARIO");
						}//    					int columnNumber_suiteNm_ACTION			=	UtilFunction.getColumnWithCellData(fileName, sheetName, columnNameAction);
						//						
						//		    			
						for(int count=1; count<rowCount; count++)
						{

							if(UtilFunction.getCellData(fileName, sheetName, columnNumber_suiteNm_RUNMODE, count).equals("Y")){
								String Scenariotext="";
								if(sheetName.equalsIgnoreCase("old Initiation"))
								{
									Scenariotext	= 	UtilFunction.getCellData("Test Data.xls", "Project Initiation", Scenariocol, count);
								}
								else
								{
								Scenariotext	= 	UtilFunction.getCellData(fileName, sheetName, Scenariocol, count);
								}
								
								if(sheetName.equalsIgnoreCase("Old Initiation"))
								{
									if(Scenariotext.equals("Positive") || Scenariotext.contains("sitive") || Scenariotext.contains("Pos")){
										OldSPI_PositiveScenarioCounter++;
									}else if(Scenariotext.equals("Negative") || Scenariotext.contains("gative") || Scenariotext.contains("gavtive") ){
										OldSPI_NegativeScenarioCounter++;
									}
									OldSPI_TotalTestCaseCounter=OldSPI_TotalTestCaseCounter+1;
								}
								else{
									if(Scenariotext.equals("Positive") || Scenariotext.contains("sitive") || Scenariotext.contains("Pos")){
										PositiveScenarioCounter++;
									}else if(Scenariotext.equals("Negative") || Scenariotext.contains("gative") || Scenariotext.contains("gavtive") ){
										NegativeScenarioCounter++;
									}
									TotalTestCaseCounter=TotalTestCaseCounter+1;
								}


								//		    					String suiteActionName				=		UtilFunction.getCellData(fileName, sheetName, ActionName, count);
								// check if user is looking for immigration or document then click on Menu>Imiggration Status only after user is searched

								if(SuiteName.equals("Immigration Status") || SuiteName.equals("Document")){

									try{
										Thread.sleep(1000);
										//visitSPILink	=	utilfunc.goToMenuSubItems("Immigration Status");
										String ProfileIConXPath			=			".//*[@id='local-navigation']//*[contains(@class,'dropdown-icon')]";
										String ImmigrationLinkXPath			=			"//*[@id='dpdmenu']//*[text()='Immigration Status']";

										// click on profile drop menu icon
										try {
											utilfunc.waitForAnElementToLoad(ProfileIConXPath, true);
											utilfunc.MakeElement(ProfileIConXPath).click();
											System.out.println("user has clicked on drop menu icon of user profile");
										} catch (Exception e) {
											// TODO Auto-generated catch block
											//e.printStackTrace();
											System.out.println("unable to click on drop menu icon of user profile");
										}
										Thread.sleep(1000);
										// click on immigration link for particular user selected
										try {
											utilfunc.waitForAnElementToLoad(ImmigrationLinkXPath, true);
											utilfunc.MakeElement(ImmigrationLinkXPath).click();
											System.out.println("unable to click on immigration status link");
											Thread.sleep(2000);
										} catch (Exception e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											System.out.println("unable to click on immigration status link");
										}

										System.out.println("user has clicked on Immigration Status link");
									}catch(Exception e){
										System.out.println("user is unable to click on Immigration Status link");
									}

									// call immigration & document modules now..

									// search for name or click on first record..
									String firstRecord	="";
									/*
									 * Code added by lokesh for principal,child,spouse
									 */
									Thread.sleep(5000);
									int row_count=utilfunc.GetObjectCount(".//*[@id='tblFamilyList']/tbody/tr");
									System.out.println("\n\t-------\n\tHere we have "+(row_count/2)+" record for add/edit.\n\t-------");

									String principal1_firstRecord="";
									String spouse1_firstRecord="";
									String child1_firstRecord="";
									for(int welcomei=1;welcomei<=row_count;welcomei+=2)
									{

										try{
											System.out.println("Wait for a min before start next record. Who's name is \""+utilfunc.MakeElement(".//*[@id='tblFamilyList']/tbody/tr["+welcomei+"]/td[3]/a").getText()+"\". \n Current loop iteration number. "+welcomei+"Please wait...   ...   ...");
											Thread.sleep(1000);
											System.out.println("\n\n\n\t==========\n\tNow we are going to add record with in "+utilfunc.MakeElement(".//*[@id='tblFamilyList']/tbody/tr["+welcomei+"]/td[3]/a").getText()+" At row number "+welcomei+"\n\t==========\n\n");
											principal1_firstRecord="";
											spouse1_firstRecord="";
											child1_firstRecord="";
					
											firstRecord="";
											String Xpath_GetPrincipalText=".//*[@id='tblFamilyList']/tbody/tr["+welcomei+"]/td[2]";
											String  gettext=utilfunc.MakeElement(Xpath_GetPrincipalText).getText();

											//System.out.println("\t---Value of i is: "+i+" and value we get is: --"+gettext+"--.");

											if(gettext.equalsIgnoreCase("Principal"))
											{
												System.out.println("\t---Value of i is: "+welcomei+" and value we get is: --"+gettext+"--.");
												try{
													firstRecord	=".//*[@id='tblFamilyList']/tbody/tr["+welcomei+"]/td[3]/a";
													principal1_firstRecord	=".//*[@id='tblFamilyList']/tbody/tr["+welcomei+"]/td[3]/a";
												}catch(Exception e){System.out.println("Unable to find the ");}
											}else if(gettext.equalsIgnoreCase("SPOUSE"))
											{
												System.out.println("\t---Value of i is: "+welcomei+" and value we get is: --"+gettext+"--.");
												try{
													firstRecord	=".//*[@id='tblFamilyList']/tbody/tr["+welcomei+"]/td[3]/a";
													spouse1_firstRecord	=".//*[@id='tblFamilyList']/tbody/tr["+welcomei+"]/td[3]/a";
												}catch(Exception e){System.out.println("Unable to find the ");}
											}else if(gettext.equalsIgnoreCase("CHILD"))
											{
												System.out.println("\t---Value of i is: "+welcomei+" and value we get is: --"+gettext+"--.");
												try{
													firstRecord	=".//*[@id='tblFamilyList']/tbody/tr["+welcomei+"]/td[3]/a";
													child1_firstRecord	=".//*[@id='tblFamilyList']/tbody/tr["+welcomei+"]/td[3]/a";
												}catch(Exception e){System.out.println("Unable to find the ");}
											}

											String current_baseurl=utilfunc.getPageUrl();

											//Excel sheet names for Spouse and child
											String Immigration_Status_Spouse="Immigration Status Spouse";
											String Immigration_Status_Child="Immigration Status Child";

											String Document_Spouse="Document Spouse";
											String Document_Child="Document Child";


											//ifrecord for Principal
											if(principal1_firstRecord!="")
											{
												try{
													try{
														utilfunc.MakeElement(principal1_firstRecord).click();
														Thread.sleep(5000);
														suiteLink=Immigration_Status_Document(SuiteName,ActionName);
													}catch(Exception e){
														System.out
														.println("unable to click for principal record "+SuiteName+" row number: " + welcomei);
													}

													try{
														openSuite =	utilfunc.waitForAnElementToLoad(suiteLink, true);
														utilfunc.MakeElement(suiteLink).click();
													}catch(Exception e){
														System.out
														.println("clicked on tab for : "+SuiteName);
													}

													if(openSuite==true){
														if(SuiteName.equals("Immigration Status")){
															// now call modules according to enable modules

															startTime = System.currentTimeMillis();

															try{
																Page_flag	=	obj_CIMS_Regression_Suite_Immigration_Status.Immigration_Documents(fileName,SuiteName,count,ActionName,current_baseurl);
																timer = utilfunc.getTimeTakenByModule(startTime);
																utilfunc.updateModuleDataForReportGeneration(SuiteName+" - Principal", Employee_namecheck, timer);
																if (Page_flag)
																{
																	status="PASS";passTestCaseCounter++;

																	if(utilfunc.globalerrormessage.equals(""))
																	{
																		utilfunc.TestngReportPass(obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio, ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status);
																	}
																	else
																	{
																		utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw,obj_CIMS_Regression_Suite_Immigration_Status.scenerio,ActionName,obj_CIMS_Regression_Suite_Immigration_Status.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	}

																	if(passCounter==false){
																		 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
																		 passCounter=true;
																	 }
																	try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio, ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
																}
																else
																{
																	status="FAIL";failTestCaseCounter++;
																	//													utilfunc.TakeScreenshot();
																	utilfunc.TestngReportFail1(obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio,ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	
																	if(failCounter==false){
											    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
											    						failCounter	= true;
										    						}
																	try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio,ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
																}
															}catch(Exception e){
																ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
																System.out.println("Script Failed");
																utilfunc.assertion();			
																utilfunc.TakeScreenshot();
															}

														}
														/****/
														if(SuiteName.equals("Document")){
															//utilfunc.zoomOut(1);
															// now call modules according to enable modules
															//	System.out.println("calling "+SuiteName+" module..");
															try{
																startTime = System.currentTimeMillis();
																Page_flag	=	obj_CIMS_Immigration_Document.Documents(fileName,SuiteName,count,ActionName,current_baseurl);
																timer = utilfunc.getTimeTakenByModule(startTime);
																utilfunc.updateModuleDataForReportGeneration(SuiteName + " - Principal", Employee_namecheck, timer);
																if (Page_flag)
																{
																	status="PASS";passTestCaseCounter++;
																	if(utilfunc.globalerrormessage.equals(""))
																	{
																		utilfunc.TestngReportPass(obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw,obj_CIMS_Immigration_Document.scenerio, ActionName,obj_CIMS_Immigration_Document.description, status);
																	}
																	else
																	{
																		utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw,obj_CIMS_Immigration_Document.scenerio,ActionName,obj_CIMS_Immigration_Document.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	}
																	if(passCounter==false){
																		 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
																		 passCounter=true;
																	 }
																	try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw, obj_CIMS_Immigration_Document.scenerio, ActionName, obj_CIMS_Immigration_Document.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
																}
																	
																
																else
																{
																	status="FAIL";failTestCaseCounter++;
																	//													utilfunc.TakeScreenshot();
																	utilfunc.TestngReportFail1(obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw,obj_CIMS_Immigration_Document.scenerio,ActionName,obj_CIMS_Immigration_Document.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	if(failCounter==false){
											    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
											    						failCounter	= true;
										    						}
																	try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio,ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
																
																}
															}catch(Exception e){
																ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
																System.out.println("Script Failed");
																utilfunc.assertion();			
																utilfunc.TakeScreenshot();
															}
														}

													}
												}catch(Exception e){
													System.out.println("Unable to find the link");
												}
												//utilfunc.zoomreset();
												webdriver.get(current_baseurl);											
											}

											//if record for spouse
											else if(spouse1_firstRecord!="")
											{
												try{
													try{
														utilfunc.MakeElement(spouse1_firstRecord).click();
														Thread.sleep(5000);
														suiteLink=Immigration_Status_Document(SuiteName,ActionName);
													}catch(Exception e){
														System.out
														.println("unable to click on first record for spouse.."+welcomei);
													}

													try{
														openSuite =	utilfunc.waitForAnElementToLoad(suiteLink, true);
														utilfunc.MakeElement(suiteLink).click();
													}catch(Exception e){
														System.out.println("unable to click ");
													}
													if(openSuite==true){
														if(SuiteName.equals("Immigration Status")){
															// now call modules according to enable modules
															//System.out.println("calling "+SuiteName+" module..");
															startTime = System.currentTimeMillis();
															try{
																Page_flag	=	obj_CIMS_Regression_Suite_Immigration_Status.Immigration_Documents(fileName,Immigration_Status_Spouse,count,ActionName,current_baseurl);
																timer = utilfunc.getTimeTakenByModule(startTime);
																utilfunc.updateModuleDataForReportGeneration(SuiteName+" - Spouse", Employee_namecheck, timer);
																if (Page_flag)
																{
																	status="PASS";passTestCaseCounter++;
																	if(utilfunc.globalerrormessage.equals(""))
																	{
																		utilfunc.TestngReportPass(obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio, ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status);
																	}
																	else
																	{
																		utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw,obj_CIMS_Regression_Suite_Immigration_Status.scenerio,ActionName,obj_CIMS_Regression_Suite_Immigration_Status.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	}
																	if(passCounter==false){
																		 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
																		 passCounter=true;
																	 }
																	try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio, ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
															
																}
																else
																{
																	status="FAIL";failTestCaseCounter++;
																	//													utilfunc.TakeScreenshot();
																	utilfunc.TestngReportFail1(obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio,ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	if(failCounter==false){
											    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
											    						failCounter	= true;
										    						}
																	try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio,ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
																}
															
							
													
															}catch(Exception e){
																ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
																System.out.println("Script Failed");
																utilfunc.assertion();			
																utilfunc.TakeScreenshot();
															}
															//utilfunc.zoomreset();
														}
														else if(SuiteName.equals("Document")){
															//utilfunc.zoomOut(1);
															// now call modules according to enable modules
															//																System.out.println("calling "+SuiteName+" module..");
															try{
																startTime = System.currentTimeMillis();
																Page_flag	=	obj_CIMS_Immigration_Document.Documents(fileName,Document_Spouse,count,ActionName,current_baseurl);
																timer = utilfunc.getTimeTakenByModule(startTime);
																utilfunc.updateModuleDataForReportGeneration(SuiteName+" - Spouse", Employee_namecheck, timer);
																if (Page_flag)
																{
																	status="PASS";passTestCaseCounter++;
																	if(utilfunc.globalerrormessage.equals(""))
																	{
																		utilfunc.TestngReportPass(obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw, obj_CIMS_Immigration_Document.scenerio, ActionName,obj_CIMS_Immigration_Document.description, status);
																	}
																	else
																	{
																		utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw,obj_CIMS_Immigration_Document.scenerio,ActionName,obj_CIMS_Immigration_Document.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	}
																	if(passCounter==false){
																		 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
																		 passCounter=true;
																	 }
																	try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw, obj_CIMS_Immigration_Document.scenerio, ActionName, obj_CIMS_Immigration_Document.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
																}
																else
																{
																	status="FAIL";failTestCaseCounter++;
																	//													utilfunc.TakeScreenshot();
																	
																	utilfunc.TestngReportFail1(obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw, obj_CIMS_Immigration_Document.scenerio,ActionName, obj_CIMS_Immigration_Document.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	if(failCounter==false){
											    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
											    						failCounter	= true;
										    						}
																	try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw, obj_CIMS_Immigration_Document.scenerio,ActionName, obj_CIMS_Immigration_Document.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
																}
																
															}catch(Exception e){
																ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
																System.out.println("Script Failed");
																utilfunc.assertion();			
																utilfunc.TakeScreenshot();
															}
														}

														//Code End here for Spouse Document
													}
												}catch(Exception e){
													System.out.println("Unable to find the link");
												}
												//utilfunc.zoomreset();
												webdriver.get(current_baseurl);
											}

											//if record is for child
											else if(child1_firstRecord!="")
											{
												try{
													try{
														utilfunc.MakeElement(child1_firstRecord).click();
														Thread.sleep(5000);
														suiteLink=Immigration_Status_Document(SuiteName,ActionName);
													}catch(Exception e){
														System.out
														.println("child record: "+welcomei);
													}

													try{
														openSuite =	utilfunc.waitForAnElementToLoad(suiteLink, true);
														utilfunc.MakeElement(suiteLink).click();
													}catch(Exception e){
														System.out
														.println("clickable ");
													}
													if(openSuite==true){
														if(SuiteName.equals("Immigration Status")){
															// now call modules according to enable modules
															//System.out.println("calling "+SuiteName+" module..");
															try{
																startTime = System.currentTimeMillis();
																Page_flag	=	obj_CIMS_Regression_Suite_Immigration_Status.Immigration_Documents(fileName,Immigration_Status_Child,count,ActionName,current_baseurl);
																timer = utilfunc.getTimeTakenByModule(startTime);
																utilfunc.updateModuleDataForReportGeneration(SuiteName+" - Child", Employee_namecheck, timer);
																if (Page_flag)
																{
																	status="PASS";passTestCaseCounter++;
																	if(utilfunc.globalerrormessage.equals(""))
																	{
																		utilfunc.TestngReportPass(obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio, ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status);
																	}
																	else
																	{
																		utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw,obj_CIMS_Regression_Suite_Immigration_Status.scenerio,ActionName,obj_CIMS_Regression_Suite_Immigration_Status.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	}
																	if(passCounter==false){
																		 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
																		 passCounter=true;
																	 }
																	try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio, ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
																}
																else
																{
																	status="FAIL";failTestCaseCounter++;
																	//													utilfunc.TakeScreenshot();
																	utilfunc.TestngReportFail1(obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio,ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	if(failCounter==false){
											    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
											    						failCounter	= true;
										    						}
																	try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Immigration_Status.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Immigration_Status.scenerio,ActionName, obj_CIMS_Regression_Suite_Immigration_Status.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
																}
															}catch(Exception e){
																ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
																System.out.println("Script Failed");
																utilfunc.assertion();			
																utilfunc.TakeScreenshot();
															}
															//utilfunc.zoomreset();
														}
														else if(SuiteName.equals("Document")){
															//utilfunc.zoomOut(1);
															// now call modules according to enable modules
															//																System.out.println("calling "+SuiteName+" module..");
															startTime = System.currentTimeMillis();
															try{
																Page_flag	=	obj_CIMS_Immigration_Document.Documents(fileName,Document_Child,count,ActionName,current_baseurl);
																timer = utilfunc.getTimeTakenByModule(startTime);
																utilfunc.updateModuleDataForReportGeneration(SuiteName+" - Child", Employee_namecheck, timer);
																if (Page_flag)
																{
																	status="PASS";passTestCaseCounter++;
																	if(utilfunc.globalerrormessage.equals(""))
																	{
																		utilfunc.TestngReportPass(obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw, obj_CIMS_Immigration_Document.scenerio, ActionName, obj_CIMS_Immigration_Document.description, status);
																	}
																	else
																	{
																		utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw,obj_CIMS_Immigration_Document.scenerio,ActionName,obj_CIMS_Immigration_Document.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	}
																	if(passCounter==false){
																		 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
																		 passCounter=true;
																	 }
																	try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw, obj_CIMS_Immigration_Document.scenerio, ActionName, obj_CIMS_Immigration_Document.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
															
																}
																else
																{
																	status="FAIL";failTestCaseCounter++;
																	//													utilfunc.TakeScreenshot();
																	utilfunc.TestngReportFail1(obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw, obj_CIMS_Immigration_Document.scenerio,ActionName, obj_CIMS_Immigration_Document.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
																	if(failCounter==false){
											    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
											    						failCounter	= true;
										    						}
																	try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Immigration_Document.testcaseid, utilfunc.Actualbrw, obj_CIMS_Immigration_Document.scenerio,ActionName, obj_CIMS_Immigration_Document.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
																}
															}catch(Exception e){
																ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
																System.out.println("Script Failed");
																utilfunc.assertion();			
																utilfunc.TakeScreenshot();
															}
														}


														// Code end here for child Document
													}
												}catch(Exception e){
													System.out.println("Unable to find the link");
												}
												//utilfunc.zoomreset();
												webdriver.get(current_baseurl);
											}
										}catch(Exception error){System.out.println("Error occured while executing for loop for itteration no."+welcomei+"\nError details are: "+error);}
									}
								}

								// run modules without employee search.. 
								else if(SuiteName.equals("Globalchek Plus")){
									//		    					CIMS_GCP_NewQuery
									// click on Globalcheck plus link under Menu
									try{
										visitSPILink	=	utilfunc.goToMenuSubItems("New Query");
										System.out.println("user has clicked on New Query link");
									}catch(Exception e){
										System.out.println("user is unable to click on New Query link");
									}

									// now call modules according to enable modules
									//																System.out.println("calling "+SuiteName+" module..");
									startTime = System.currentTimeMillis();
									try{
										Page_flag	=	obj_CIMS_GCP_NewQuery.GCP_NewQuery_Initiation_Page(fileName,sheetName,count,ActionName);
										timer = utilfunc.getTimeTakenByModule(startTime);
										utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
										if (Page_flag)
										{
											status="PASS";passTestCaseCounter++;
											if(utilfunc.globalerrormessage.equals(""))
											{
												utilfunc.TestngReportPass(obj_CIMS_GCP_NewQuery.testcaseid, utilfunc.Actualbrw, obj_CIMS_GCP_NewQuery.scenerio, ActionName, obj_CIMS_GCP_NewQuery.description, status);
											}
											else
											{
												utilfunc.TestngReportNegativePassTestcase(obj_CIMS_GCP_NewQuery.testcaseid, utilfunc.Actualbrw,obj_CIMS_GCP_NewQuery.scenerio,ActionName,obj_CIMS_GCP_NewQuery.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											}
											if(passCounter==false){
												 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
												 passCounter=true;
											 }
											try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_GCP_NewQuery.testcaseid, utilfunc.Actualbrw, obj_CIMS_GCP_NewQuery.scenerio, ActionName, obj_CIMS_GCP_NewQuery.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
										}
										else
										{
											status="FAIL";failTestCaseCounter++;
											utilfunc.TakeScreenshot();
											utilfunc.TestngReportFail1(obj_CIMS_GCP_NewQuery.testcaseid, utilfunc.Actualbrw, obj_CIMS_GCP_NewQuery.scenerio,ActionName, obj_CIMS_GCP_NewQuery.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											if(failCounter==false){
					    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
					    						failCounter	= true;
				    						}
											try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_GCP_NewQuery.testcaseid, utilfunc.Actualbrw, obj_CIMS_GCP_NewQuery.scenerio,ActionName, obj_CIMS_GCP_NewQuery.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
										}
									}catch(Exception e){
										ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
										System.out.println("Script Failed");
										utilfunc.assertion();			
										utilfunc.TakeScreenshot();
									}
								}
								//		    				/****/
								//LOKESH append this code for "ALL MY TASKS" on welcome page on 11-April-2016 ===START HERE===
								/*else if(SuiteName.equals("All My Tasks"))
		    				{
		    					System.out.println("\n---\n---\n---\tAll my tasks");

		    					startTime = System.currentTimeMillis();

								try{
								Page_flag	=	obj_CIMS_Regression_Suite_AllMyTasks.AllMyTasks(fileName,SuiteName,count,ActionName);
								timer = utilfunc.getTimeTakenByModule(startTime);
								utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
								if (Page_flag)
								{
									status="PASS";passTestCaseCounter++;
									if(utilfunc.globalerrormessage.equals(""))
									{
										utilfunc.TestngReportPass(obj_CIMS_Regression_Suite_AllMyTasks.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_AllMyTasks.scenerio, ActionName, obj_CIMS_Regression_Suite_AllMyTasks.description, status);
									}
									else
									{
										utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Regression_Suite_AllMyTasks.testcaseid, utilfunc.Actualbrw,obj_CIMS_Regression_Suite_AllMyTasks.scenerio,ActionName,obj_CIMS_Regression_Suite_AllMyTasks.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
									}
								}
								else
								{
									status="FAIL";failTestCaseCounter++;
//									utilfunc.TakeScreenshot();
									utilfunc.TestngReportFail1(obj_CIMS_Regression_Suite_AllMyTasks.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_AllMyTasks.scenerio,ActionName, obj_CIMS_Regression_Suite_AllMyTasks.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
								}
								}catch(Exception e){
									ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
									System.out.println("Script Failed");
									utilfunc.assertion();			
									utilfunc.TakeScreenshot();
									}

		    				}*/

								//LOKESH append this code for "ALL MY TASKS" on welcome page on 11-April-2016 ===END HERE===

								//LOKESH append this code for "News" on welcome page on 11-April-2016 ===START HERE===
								else if(SuiteName.equals("News"))
								{
									System.out.println("We  are on news.........");
									try{
										String curnturlis=webdriver.getCurrentUrl();
										int totallenth=curnturlis.length();
										int positon=curnturlis.indexOf("com/");
									    if((totallenth-(positon+4))>0)
										{
										System.out.println("we have to go to home page...");
										utilfunc.MakeElement(".//*[@id='gn-menu']//*[@id='logo']/a").click();
										Thread.sleep(2000);
										}
									}catch(Exception error ){System.out.println("unable to click on logo to go to home page");}
									
									String NewsSectionisAssignedorNot_gettext="";
									String NewsSectionisAssignedorNot_Xpath=".//*[@id='panel-header' and contains(text(),'News')]"; 
									try{
										NewsSectionisAssignedorNot_gettext=utilfunc.MakeElement(NewsSectionisAssignedorNot_Xpath).getText();
									}catch(Exception error){}

									startTime = System.currentTimeMillis();

									//check News is assigned to the user or not.
									if(NewsSectionisAssignedorNot_gettext.equalsIgnoreCase("News"))
									{//News is assigned to the user
										try{
											Page_flag	=	obj_CIMS_Regression_Suite_News.News(fileName,SuiteName,count,ActionName);
											timer = utilfunc.getTimeTakenByModule(startTime);
											utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
											if (Page_flag)
											{
												status="PASS";passTestCaseCounter++;
												if(utilfunc.globalerrormessage.equals(""))
												{
													utilfunc.TestngReportPass(obj_CIMS_Regression_Suite_News.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_News.scenerio, ActionName, obj_CIMS_Regression_Suite_News.description, status);
												}
												else
												{
													utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Regression_Suite_News.testcaseid, utilfunc.Actualbrw,obj_CIMS_Regression_Suite_News.scenerio,ActionName,obj_CIMS_Regression_Suite_News.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												}
												if(passCounter==false){
													 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
													 passCounter=true;
												 }
												try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_News.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_News.scenerio, ActionName, obj_CIMS_Regression_Suite_News.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
											}
											else
											{
												status="FAIL";failTestCaseCounter++;
												//									utilfunc.TakeScreenshot();
												utilfunc.TestngReportFail1(obj_CIMS_Regression_Suite_News.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_News.scenerio,ActionName, obj_CIMS_Regression_Suite_News.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												if(failCounter==false){
						    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
						    						failCounter	= true;
					    						}
												try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_News.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_News.scenerio,ActionName, obj_CIMS_Regression_Suite_News.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
											}
										}catch(Exception e){
											ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
											System.out.println("Script Failed");
											utilfunc.assertion();			
											utilfunc.TakeScreenshot();
										}
									}
									else
									{//News is not assigned to the user


										Thread.sleep(3000);
										timer = utilfunc.getTimeTakenByModule(startTime);
										status="PASS";
										String Errormessage="";
										String NotAssignTestCaseID="";
										String NotAssignScenerio="";
										String NotAssignTestCaseDescription="";
										int columnNumber_TCID;
										int columnNumber_Scenario;
										int columnNumber_TestCaseDescription;

										utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
										Errormessage=""+SuiteName+" is not assigned to "+Employee_namecheck+" User";
										System.out.println(Errormessage);

										columnNumber_TCID						=		UtilFunction.getColumnWithCellData(fileName, sheetName, "TCID");
										columnNumber_Scenario					=		UtilFunction.getColumnWithCellData(fileName, sheetName, "Scenario");
										columnNumber_TestCaseDescription		=		UtilFunction.getColumnWithCellData(fileName, sheetName, "Test Case Description");

										NotAssignTestCaseID=UtilFunction.getCellData(fileName, sheetName, columnNumber_TCID, count);
										NotAssignScenerio=UtilFunction.getCellData(fileName, sheetName, columnNumber_Scenario, count);
										NotAssignTestCaseDescription=UtilFunction.getCellData(fileName, sheetName, columnNumber_TestCaseDescription, count);

										utilfunc.TestngReportFail(NotAssignTestCaseID, utilfunc.Actualbrw, NotAssignScenerio,ActionName,NotAssignTestCaseDescription,status,Errormessage);
										NotAssignedModuleCounter++;
										
										NumberOfNotAssignModule.add(SuiteName);
									}

								}

								//LOKESH append this code for "ALL MY TASKS" on welcome page on 11-April-2016 ===END HERE===

								/****/
								else if(SuiteName.equals("Old Initiation") || SuiteName.equals("Initiate a single project") 
										|| SuiteName.equals("Initiate multiple projects")){

									// use is looking for module that do not require employee to search before going on the module..

									// fixing link for old initiation page
										/*if(SuiteName.equals("Old Initiation")){
		    						webdriver.get("http://cobaltqa.daxima.com/Initiation");
		    					}*/

									try{
										// check if current browser is IE8 then click link for IE8 only
										System.out.println("check if current browser is IE then click link for IE only");

										String InitiationLink		=		"//*[contains(@id,'divis')]";
										//	    					String InitiateLinkXPath	=		"SinglepageInitiation"; // this is used to get the link of enabled(display: none is missing) link
												int InitiationLinkGetObjCounter=0;
												InitiationLinkGetObjCounter=utilfunc.GetObjectCount(InitiationLink);
										for(int w=1;w<=InitiationLinkGetObjCounter;w++){
											Thread.sleep(2500);

											String InitiateLinkXPath	=	InitiationLink+"["+w+"]";
											Boolean	styleAttrPresent	=		utilfunc.isAttributePresent(utilfunc.MakeElement(InitiateLinkXPath), "style");

											if(styleAttrPresent==false){
												System.out.println("style tag not present.."+utilfunc.MakeElement(InitiateLinkXPath).getText());
												// clicking on initiation page.. let us save the id to identify if we need to call old initiation page
												IdentifyIE			=		utilfunc.MakeElement(InitiateLinkXPath).getAttribute("id");
												System.out.println("ie-: "+IdentifyIE);
												String newInitiateLinkXPath=InitiateLinkXPath+"/a";
												try {
													utilfunc.MakeElement(newInitiateLinkXPath).click();
												} catch (Exception e) {
													System.out.println("unable to click on single page initiation link");
												}
												break;
											}

										}

									}catch(Exception e){
										System.out.println("unable to go to "+ SuiteName + " page");
									}

									Thread.sleep(3000);
									String LinkPrefix		=		".//*[@id='panel-body-container']//*[contains(@class,'btn-group')]";

									if(SuiteName.equals("Initiate a single project") || SuiteName.equals("Old Initiation")){


										Thread.sleep(2000);

										try {
											suiteLink			=		LinkPrefix	+	"//*[contains(@href,'single')]";
											openSuite =	utilfunc.waitForAnElementToLoad(suiteLink, true);
											utilfunc.MakeElement(suiteLink).click();
											System.out.println("clicked on single page initiation link");
										} catch (Exception e) {
											// TODO Auto-generated catch block
											//e.printStackTrace();
											System.out.println("unable to click on single page initiation link");
										}

										// now call modules according to enable modules

										System.out.println("calling SPI add module..");
										////TIMER START///////
										startTime = System.currentTimeMillis();

										//								if(IdentifyIE.equals("divisIE8")){
										// in case of IE8 browser call old single page initiation

										if(SuiteName.equals("Old Initiation")){
											try{

												////TIMER START///////
												startTime = System.currentTimeMillis();
												//Project Initiate page
												obj_Project_Initiation.Project_Initiation_Page();

												//Project_Initiation_Step1_Page
												boolean FlagStep1=obj_Project_Initiation.Project_Initiation_Step1_Page();
												timer = utilfunc.getTimeTakenByModule(startTime);

												utilfunc.updateModuleDataForReportGeneration(SuiteName + " - Step 1", Employee_namecheck, timer);
												if(!FlagStep1){
													System.out.println("Step 1 Script Failed due to an Exception");	
													status="FAIL";  
													OldSPI_failTestCaseCounter=OldSPI_failTestCaseCounter+1;
													utilfunc.TakeScreenshot();
													utilfunc.TestngReportFail1(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario,ActionName, obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												}
												else{
													System.out.println("Successfully Executed- Step 1 for Project Initation");
													status="PASS";
													OldSPI_passTestCaseCounter=OldSPI_passTestCaseCounter+1;
													if(utilfunc.globalerrormessage.equals(""))
													{
														utilfunc.TestngReportPass(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario, ActionName, obj_Project_Initiation.testcasedescription, status);
													}
													else
													{
														utilfunc.TestngReportNegativePassTestcase(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw,obj_Project_Initiation.testcasescenario,ActionName,obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
													}
												}

												//Project_Initiation_Step2_Page
												Thread.sleep(1500);
												////TIMER START///////
												startTime = System.currentTimeMillis();
												boolean FlagStep2=obj_Project_Initiation.Project_Initiation_Step2_Page();
												timer = utilfunc.getTimeTakenByModule(startTime);

												utilfunc.updateModuleDataForReportGeneration(SuiteName + " - Step 2", Employee_namecheck, timer);
												if(!FlagStep2){
													System.out.println("Step 2 Script Failed due to an Exception");
													status="FAIL";
													OldSPI_failTestCaseCounter=OldSPI_failTestCaseCounter+1;
													utilfunc.TakeScreenshot();
													utilfunc.TestngReportFail1(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario,ActionName, obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												}
												else{
													System.out.println("Successfully Executed- Step 2 for Project Initation");
													status="PASS";
													OldSPI_passTestCaseCounter=OldSPI_passTestCaseCounter+1;
													if(utilfunc.globalerrormessage.equals(""))
													{
														utilfunc.TestngReportPass(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario, ActionName, obj_Project_Initiation.testcasedescription, status);
													}
													else
													{
														utilfunc.TestngReportNegativePassTestcase(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw,obj_Project_Initiation.testcasescenario,ActionName,obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
													}
												}

												//Project_Initiation_Step3_Page
												Thread.sleep(1500);
												////TIMER START///////
												startTime = System.currentTimeMillis();
												boolean FlagStep3=obj_Project_Initiation.Project_Initiation_Step3_Page();
												timer = utilfunc.getTimeTakenByModule(startTime);

												utilfunc.updateModuleDataForReportGeneration(SuiteName + " - Step 3", Employee_namecheck, timer);
												if(!FlagStep3){
													System.out.println("Step 3 Script Failed due to an Exception");
													status="FAIL";
													OldSPI_failTestCaseCounter=OldSPI_failTestCaseCounter+1;
													utilfunc.TakeScreenshot();
													utilfunc.TestngReportFail1(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario,ActionName, obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);

												}
												else{
													System.out.println("Successfully Executed- Step 3 for Project Initation");
													status="PASS";
													OldSPI_passTestCaseCounter=OldSPI_passTestCaseCounter+1;
													if(utilfunc.globalerrormessage.equals(""))
													{
														utilfunc.TestngReportPass(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario, ActionName, obj_Project_Initiation.testcasedescription, status);
													}
													else
													{
														utilfunc.TestngReportNegativePassTestcase(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw,obj_Project_Initiation.testcasescenario,ActionName,obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
													}
												}

												//Project_Initiation_Step4_Page
												Thread.sleep(1500);
												////TIMER START///////
												startTime = System.currentTimeMillis();
												boolean FlagStep4=obj_Project_Initiation.Project_Initiation_Step4_Page();
												timer = utilfunc.getTimeTakenByModule(startTime);

												utilfunc.updateModuleDataForReportGeneration(SuiteName + " - Step 4", Employee_namecheck, timer);
												if(!FlagStep4){
													System.out.println("Step 4 Script Failed due to an Exception");
													status="FAIL";
													OldSPI_failTestCaseCounter=OldSPI_failTestCaseCounter+1;
													utilfunc.TakeScreenshot();
													utilfunc.TestngReportFail1(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario,ActionName, obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);										
												}
												else{
													System.out.println("Successfully Executed- Step 4 for Project Initation");
													status="PASS";
													OldSPI_passTestCaseCounter=OldSPI_passTestCaseCounter+1;
													if(utilfunc.globalerrormessage.equals(""))
													{
														utilfunc.TestngReportPass(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario, ActionName, obj_Project_Initiation.testcasedescription, status);
													}
													else
													{
														utilfunc.TestngReportNegativePassTestcase(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw,obj_Project_Initiation.testcasescenario,ActionName,obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
													}
												}

												//Project_Initiation_Step5_Page
												Thread.sleep(1500);
												////TIMER START///////
												startTime = System.currentTimeMillis();
												boolean FlagStep5=obj_Project_Initiation.Project_Initiation_Step5_Page();
												timer = utilfunc.getTimeTakenByModule(startTime);

												utilfunc.updateModuleDataForReportGeneration(SuiteName + " - Step 5", Employee_namecheck, timer);
												if(!FlagStep5){
													System.out.println("Script Failed due to an Exception");
													status="FAIL";
													OldSPI_failTestCaseCounter=OldSPI_failTestCaseCounter+1;
													utilfunc.TakeScreenshot();
													utilfunc.TestngReportFail1(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario,ActionName, obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);										
												}
												else{
													System.out.println("Successfully Executed- Step 5 for Project Initation");
													status="PASS";
													OldSPI_passTestCaseCounter=OldSPI_passTestCaseCounter+1;
													if(utilfunc.globalerrormessage.equals(""))
													{
														utilfunc.TestngReportPass(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario, ActionName, obj_Project_Initiation.testcasedescription, status);
													}
													else
													{
														utilfunc.TestngReportNegativePassTestcase(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw,obj_Project_Initiation.testcasescenario,ActionName,obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
													}
												}

												//Project_Initiation_Step6_Page
												Thread.sleep(3500);
												////TIMER START///////
												startTime = System.currentTimeMillis();
												boolean FlagStep6=obj_Project_Initiation.Project_Initiation_Step6_Page();
												timer = utilfunc.getTimeTakenByModule(startTime);

												utilfunc.updateModuleDataForReportGeneration(SuiteName + " - Step 6", Employee_namecheck, timer);
												if(!FlagStep6){
													System.out.println("Script Failed due to an Exception");
													status="FAIL";
													OldSPI_failTestCaseCounter=OldSPI_failTestCaseCounter+1;
													utilfunc.TakeScreenshot();
													utilfunc.TestngReportFail1(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario,ActionName, obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												}
												else{
													System.out.println("Successfully Executed- Step 6 for Project Initation");
													status="PASS";
													OldSPI_passTestCaseCounter=OldSPI_passTestCaseCounter+1;
													if(utilfunc.globalerrormessage.equals(""))
													{
														utilfunc.TestngReportPass(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw, obj_Project_Initiation.testcasescenario, ActionName, obj_Project_Initiation.testcasedescription, status);
													}
													else
													{
														utilfunc.TestngReportNegativePassTestcase(obj_Project_Initiation.testcaseId, utilfunc.Actualbrw,obj_Project_Initiation.testcasescenario,ActionName,obj_Project_Initiation.testcasedescription, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
													}

												}
												
												

											}catch(Exception e){
												ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
												System.out.println("Script Failed");
												utilfunc.assertion();
												obj_Project_Initiation.TakeScreenshot();
											}


											System.out.println("========\n========\n========");
											System.out.println("OldSPI_PositiveScenarioCounter : "+OldSPI_PositiveScenarioCounter);
											System.out.println("OldSPI_NegativeScenarioCounter : "+OldSPI_NegativeScenarioCounter);
											System.out.println("OldSPI_TotalTestCaseCounter : "+OldSPI_TotalTestCaseCounter);
											System.out.println("OldSPI_passTestCaseCounter : "+OldSPI_passTestCaseCounter);
											System.out.println("OldSPI_failTestCaseCounter : "+OldSPI_failTestCaseCounter);
											System.out.println("OldSPI_NotAssignedModuleCounter : "+OldSPI_NotAssignedModuleCounter);
											System.out.println("========\n========\n========");

											// adding dashboard code here..
											String OldSPI_PositiveScenarioCount="";
											String OldSPI_NegativeScenarioCount="";
											String OldSPI_ModuleCount="";
											String OldSPI_TotalTestCaseCount="";
											String OldSPI_FinalPositiveCount="";
											String OldSPI_FinalNegativeCount="";
											String OldSPI_NotAssignedModuleCount="";

											try{	OldSPI_PositiveScenarioCount			=	Integer.toString(OldSPI_PositiveScenarioCounter);	}catch(Exception error){}
											try{	OldSPI_NegativeScenarioCount			=	Integer.toString(OldSPI_NegativeScenarioCounter);	}catch(Exception error){}
											try{	OldSPI_ModuleCount						=	Integer.toString(OldSPI_ModuleCounter);			}catch(Exception error){}
											try{	OldSPI_TotalTestCaseCount				=	Integer.toString(OldSPI_TotalTestCaseCounter);	}catch(Exception error){}
											try{	OldSPI_FinalPositiveCount				=	Integer.toString(OldSPI_passTestCaseCounter);	}catch(Exception error){}
											try{	OldSPI_FinalNegativeCount				=	Integer.toString(OldSPI_failTestCaseCounter);	}catch(Exception error){}
											try{	OldSPI_NotAssignedModuleCount			=	Integer.toString(OldSPI_NotAssignedModuleCounter);	}catch(Exception error){}
											
											//utilfunc.TestngDashBoardReport("Left Navigation",OldSPI_ModuleCount,OldSPI_TotalTestCaseCount,OldSPI_PositiveScenarioCount,OldSPI_NegativeScenarioCount,OldSPI_FinalPositiveCount,OldSPI_FinalNegativeCount,OldSPI_NotAssignedModuleCount,OldSPI_NotAssignedModuleCount);
											TotalTime = utilfunc.getTimeTakenByModule(startTotalTime);
											try{
												obj_Report_Dashboard.generateReportForSuite(RegressionSuites,OldSPI_ModuleCount,OldSPI_TotalTestCaseCount,OldSPI_PositiveScenarioCount,OldSPI_NegativeScenarioCount,
													OldSPI_FinalPositiveCount,OldSPI_FinalNegativeCount,TotalTime,OldSPI_NotAssignedModuleCount);
											}catch(Exception e){
												System.out.println("unable to call & generate dashboard report for old..");
											}


											

										}else if(SuiteName.equals("Initiate a single project")){


											Page_flag	=	obj_CIMS_Single_Project_Initiation.Single_Project_Initiation_Suite(fileName,sheetName,count,ActionName,Employee_namecheck);
											//		    					}
											timer = utilfunc.getTimeTakenByModule(startTime);
											utilfunc.updateModuleDataForReportGeneration(SuiteName+" Final Report", Employee_namecheck, timer);

											//								}else{

											if (Page_flag)
											{
												status="PASS";passTestCaseCounter++;
												if(utilfunc.globalerrormessage.equals(""))
												{
													utilfunc.TestngReportPass(obj_CIMS_Single_Project_Initiation.testcaseid, utilfunc.Actualbrw, obj_CIMS_Single_Project_Initiation.scenerio, ActionName, obj_CIMS_Single_Project_Initiation.description, status);
												}
												else
												{
													utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Single_Project_Initiation.testcaseid, utilfunc.Actualbrw,obj_CIMS_Single_Project_Initiation.scenerio,ActionName,obj_CIMS_Single_Project_Initiation.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												}
												if(passCounter==false){
													 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
													 passCounter=true;
												 }
												try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Single_Project_Initiation.testcaseid, utilfunc.Actualbrw, obj_CIMS_Single_Project_Initiation.scenerio, ActionName, obj_CIMS_Single_Project_Initiation.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
											}
											else
											{
												status="FAIL";failTestCaseCounter++;utilfunc.TakeScreenshot();
												utilfunc.TestngReportFail1(obj_CIMS_Single_Project_Initiation.testcaseid, utilfunc.Actualbrw, obj_CIMS_Single_Project_Initiation.scenerio,ActionName, obj_CIMS_Single_Project_Initiation.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);

												if(failCounter==false){
						    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
						    						failCounter	= true;
					    						}
												try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Single_Project_Initiation.testcaseid, utilfunc.Actualbrw, obj_CIMS_Single_Project_Initiation.scenerio,ActionName, obj_CIMS_Single_Project_Initiation.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
											}
										}

									}else if(SuiteName.equals("Initiate multiple projects")){

										// multiple projects code starts here..
										suiteLink			=		LinkPrefix	+	"//*[contains(@href,'multi')]";
										openSuite =	utilfunc.waitForAnElementToLoad(suiteLink, true);
										utilfunc.MakeElement(suiteLink).click();
										System.out.println("calling "+SuiteName+" module..");
										////TIMER START///////
										startTime = System.currentTimeMillis();

										Page_flag	=	obj_CIMS_Regresssion_Suite_Bulk_Initiation.Bulk_Initiation(fileName,SuiteName,count,ActionName);

										timer = utilfunc.getTimeTakenByModule(startTime);

										utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);

										if (Page_flag)
										{
											status="PASS";passTestCaseCounter++;
											if(utilfunc.globalerrormessage.equals(""))
											{
												utilfunc.TestngReportPass(obj_CIMS_Regresssion_Suite_Bulk_Initiation.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regresssion_Suite_Bulk_Initiation.scenerio, ActionName, obj_CIMS_Regresssion_Suite_Bulk_Initiation.description, status);
											}
											else
											{
												utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Regresssion_Suite_Bulk_Initiation.testcaseid, utilfunc.Actualbrw,obj_CIMS_Regresssion_Suite_Bulk_Initiation.scenerio,ActionName,obj_CIMS_Regresssion_Suite_Bulk_Initiation.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											}
											if(passCounter==false){
												 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
												 passCounter=true;
											 }
											try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regresssion_Suite_Bulk_Initiation.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regresssion_Suite_Bulk_Initiation.scenerio, ActionName, obj_CIMS_Regresssion_Suite_Bulk_Initiation.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
										}
										else
										{
											status="FAIL";failTestCaseCounter++;utilfunc.TakeScreenshot();
											utilfunc.TestngReportFail1(obj_CIMS_Regresssion_Suite_Bulk_Initiation.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regresssion_Suite_Bulk_Initiation.scenerio,ActionName, obj_CIMS_Regresssion_Suite_Bulk_Initiation.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);

											if(failCounter==false){
					    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
					    						failCounter	= true;
				    						}
											try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regresssion_Suite_Bulk_Initiation.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regresssion_Suite_Bulk_Initiation.scenerio,ActionName, obj_CIMS_Regresssion_Suite_Bulk_Initiation.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
										}

									}

									System.out.println("suite link: "+suiteLink);
								}


								// Lokesh add these line(s) on 06-May-2016 for Advance Project search
								else if(SuiteName.equals("Advanced Search Project"))
								{
									String AdvSProjectisAssignedorNot_gettext="";
									String AdvSProjectsisAssignedorNot_Xpath="//*[@id='gn-menu']//*[text()='Projects']"; 
									try{
										Thread.sleep(1500);
										AdvSProjectisAssignedorNot_gettext=utilfunc.MakeElement(AdvSProjectsisAssignedorNot_Xpath).getText();
									}catch(Exception error){}
									utilfunc.ErrorMessage1="";utilfunc.ErrorMessage2="";utilfunc.globalerrormessage="";
									utilfunc.ErrorMessage4="";utilfunc.ErrorMessage5="";
									startTime = System.currentTimeMillis();

									//check News is assigned to the user or not.
									if(AdvSProjectisAssignedorNot_gettext.equalsIgnoreCase("Projects"))
									{
										utilfunc.ErrorMessage1="";utilfunc.ErrorMessage2="";utilfunc.globalerrormessage="";
										utilfunc.ErrorMessage4="";utilfunc.ErrorMessage5="";
										// click on link
										try{
											utilfunc.MakeElement(AdvSProjectsisAssignedorNot_Xpath).click();
										}catch(Exception e){
											System.out.println("unable to click on Projects icons");
										}
										try{
											Page_flag	=	obj_Project_Search.advanced_Project_Search(fileName,SuiteName,count,ActionName);
											timer = utilfunc.getTimeTakenByModule(startTime);
											utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
											if (Page_flag)
											{
												status="PASS";passTestCaseCounter++;
												if(utilfunc.globalerrormessage.equals(""))
												{
													utilfunc.TestngReportPass(obj_Project_Search.testcaseid, utilfunc.Actualbrw, obj_Project_Search.scenerio, ActionName, obj_Project_Search.description, status);
												}
												else
												{
													utilfunc.TestngReportNegativePassTestcase(obj_Project_Search.testcaseid, utilfunc.Actualbrw,obj_Project_Search.scenerio,ActionName,obj_Project_Search.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												}
												if(passCounter==false){
													 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
													 passCounter=true;
												 }
												try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_Project_Search.testcaseid, utilfunc.Actualbrw, obj_Project_Search.scenerio, ActionName, obj_Project_Search.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
											}
											else
											{
												status="FAIL";failTestCaseCounter++;
												//utilfunc.TakeScreenshot();
												utilfunc.TestngReportFail1(obj_Project_Search.testcaseid, utilfunc.Actualbrw, obj_Project_Search.scenerio,ActionName, obj_Project_Search.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												if(failCounter==false){
						    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
						    						failCounter	= true;
					    						}
												try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_Project_Search.testcaseid, utilfunc.Actualbrw, obj_Project_Search.scenerio,ActionName, obj_Project_Search.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
											}
										}catch(Exception e){
											ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
											System.out.println("Script Failed");
											utilfunc.assertion();			
											utilfunc.TakeScreenshot();
										}
									}
									else
									{//Advance Project Search is not assigned to the user
										Thread.sleep(3000);
										timer = utilfunc.getTimeTakenByModule(startTime);
										status="PASS";
										String Errormessage="";
										String NotAssignTestCaseID="";
										String NotAssignScenerio="";
										String NotAssignTestCaseDescription="";
										int columnNumber_TCID;
										int columnNumber_Scenario;
										int columnNumber_TestCaseDescription;

										utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
										Errormessage=""+SuiteName+" is not assigned to "+Employee_namecheck+" User";
										System.out.println(Errormessage);

										columnNumber_TCID						=		UtilFunction.getColumnWithCellData(fileName, sheetName, "TCID");
										columnNumber_Scenario					=		UtilFunction.getColumnWithCellData(fileName, sheetName, "Scenario");
										columnNumber_TestCaseDescription		=		UtilFunction.getColumnWithCellData(fileName, sheetName, "Test Case Description");

										NotAssignTestCaseID=UtilFunction.getCellData(fileName, sheetName, columnNumber_TCID, count);
										NotAssignScenerio=UtilFunction.getCellData(fileName, sheetName, columnNumber_Scenario, count);
										NotAssignTestCaseDescription=UtilFunction.getCellData(fileName, sheetName, columnNumber_TestCaseDescription, count);

										utilfunc.TestngReportFail(NotAssignTestCaseID, utilfunc.Actualbrw, NotAssignScenerio,ActionName,NotAssignTestCaseDescription,status,Errormessage);
										NotAssignedModuleCounter++;
										NumberOfNotAssignModule.add(SuiteName);
									}

								}
								// Lokesh add above line(s) on 06-May-2016 for Advance Project search


								//* code for advanced employee  search..
								else if(SuiteName.equals("Advanced Search Employee"))
								{
									String AdvSEmpisAssignedorNot_gettext="";
									String AdvSEmpisAssignedorNot_Xpath="//*[@id='gn-menu']//*[text()='Employees']"; 
									try{
										Thread.sleep(1500);
										AdvSEmpisAssignedorNot_gettext=utilfunc.MakeElement(AdvSEmpisAssignedorNot_Xpath).getText();
									}catch(Exception error){}

									startTime = System.currentTimeMillis();

									//check News is assigned to the user or not.
									if(AdvSEmpisAssignedorNot_gettext.equalsIgnoreCase("Employees"))
									{

										// click on link
										try{
											utilfunc.MakeElement(AdvSEmpisAssignedorNot_Xpath).click();
										}catch(Exception e){
											System.out.println("unable to click on employee icons");
										}
										try{
											Page_flag	=	obj_Employee_Search.advanced_Employee_Search(fileName,SuiteName,count,ActionName);
											timer = utilfunc.getTimeTakenByModule(startTime);
											utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
											if (Page_flag)
											{
												status="PASS";passTestCaseCounter++;
												if(utilfunc.globalerrormessage.equals(""))
												{
													utilfunc.TestngReportPass(obj_Employee_Search.testcaseid, utilfunc.Actualbrw, obj_Employee_Search.scenerio, ActionName, obj_Employee_Search.description, status);
												}
												else
												{
													utilfunc.TestngReportNegativePassTestcase(obj_Employee_Search.testcaseid, utilfunc.Actualbrw,obj_Employee_Search.scenerio,ActionName,obj_Employee_Search.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												}
												if(passCounter==false){
													 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
													 passCounter=true;
												 }
												try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_Employee_Search.testcaseid, utilfunc.Actualbrw, obj_Employee_Search.scenerio, ActionName, obj_Employee_Search.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
											}
											else
											{
												status="FAIL";failTestCaseCounter++;
												//									utilfunc.TakeScreenshot();
												utilfunc.TestngReportFail1(obj_Employee_Search.testcaseid, utilfunc.Actualbrw, obj_Employee_Search.scenerio,ActionName, obj_Employee_Search.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												if(failCounter==false){
						    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
						    						failCounter	= true;
					    						}
												try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_Employee_Search.testcaseid, utilfunc.Actualbrw, obj_Employee_Search.scenerio,ActionName, obj_Employee_Search.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
											}
										}catch(Exception e){
											ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
											System.out.println("Script Failed");
											utilfunc.assertion();			
											utilfunc.TakeScreenshot();
										}
									}
									else
									{//News is not assigned to the user


										Thread.sleep(3000);
										timer = utilfunc.getTimeTakenByModule(startTime);
										status="PASS";
										String Errormessage="";
										String NotAssignTestCaseID="";
										String NotAssignScenerio="";
										String NotAssignTestCaseDescription="";
										int columnNumber_TCID;
										int columnNumber_Scenario;
										int columnNumber_TestCaseDescription;

										utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
										Errormessage=""+SuiteName+" is not assigned to "+Employee_namecheck+" User";
										System.out.println(Errormessage);

										columnNumber_TCID						=		UtilFunction.getColumnWithCellData(fileName, sheetName, "TCID");
										columnNumber_Scenario					=		UtilFunction.getColumnWithCellData(fileName, sheetName, "Scenario");
										columnNumber_TestCaseDescription		=		UtilFunction.getColumnWithCellData(fileName, sheetName, "Test Case Description");

										NotAssignTestCaseID=UtilFunction.getCellData(fileName, sheetName, columnNumber_TCID, count);
										NotAssignScenerio=UtilFunction.getCellData(fileName, sheetName, columnNumber_Scenario, count);
										NotAssignTestCaseDescription=UtilFunction.getCellData(fileName, sheetName, columnNumber_TestCaseDescription, count);

										utilfunc.TestngReportFail(NotAssignTestCaseID, utilfunc.Actualbrw, NotAssignScenerio,ActionName,NotAssignTestCaseDescription,status,Errormessage);
										NotAssignedModuleCounter++;
										NumberOfNotAssignModule.add(SuiteName);
									}

								}
								//* advanced employee search **/


								
								// secure messaging.. //
								else if(SuiteName.equals("Secure Messaging")){
									

									String Secure_Messaging_Xpath=".//*[@id='nav-parent']//*[@class='pull-right']//a[@id='nav-messages']"; 

										// click on link
										try{
										    Thread.sleep(1000);
											
									      utilfunc.MakeElement(Secure_Messaging_Xpath).click();
									      Thread.sleep(1000);
										}catch(Exception e){
											System.out.println("unable to click on employee icons");
										}
										try{
											Page_flag	=	obj_CIMS_Secure_Messaging.Secure_Messaging(fileName,SuiteName,count,ActionName);
											timer = utilfunc.getTimeTakenByModule(startTime);
											utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
											if (Page_flag)
											{
												status="PASS";passTestCaseCounter++;
												if(utilfunc.globalerrormessage.equals(""))
												{
													utilfunc.TestngReportPass(obj_CIMS_Secure_Messaging.testcaseid, utilfunc.Actualbrw, obj_CIMS_Secure_Messaging.scenerio, ActionName, obj_CIMS_Secure_Messaging.description, status);
												}
												else
												{
													utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Secure_Messaging.testcaseid, utilfunc.Actualbrw,obj_CIMS_Secure_Messaging.scenerio,ActionName,obj_CIMS_Secure_Messaging.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												}
												if(passCounter==false){
													 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
													 passCounter=true;
												 }
												try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Secure_Messaging.testcaseid, utilfunc.Actualbrw, obj_CIMS_Secure_Messaging.scenerio, ActionName, obj_CIMS_Secure_Messaging.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
						
											}
											else
											{
												status="FAIL";failTestCaseCounter++;
												//									utilfunc.TakeScreenshot();
												utilfunc.TestngReportFail1(obj_CIMS_Secure_Messaging.testcaseid, utilfunc.Actualbrw, obj_CIMS_Secure_Messaging.scenerio,ActionName, obj_CIMS_Secure_Messaging.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
												if(failCounter==false){
						    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
						    						failCounter	= true;
					    						}
												try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Secure_Messaging.testcaseid, utilfunc.Actualbrw, obj_CIMS_Secure_Messaging.scenerio,ActionName, obj_CIMS_Secure_Messaging.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
											}
										}catch(Exception e){
											ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
											System.out.println("Script Failed");
											utilfunc.assertion();			
											utilfunc.TakeScreenshot();
										}
									
									/*

										Thread.sleep(3000);
										timer = utilfunc.getTimeTakenByModule(startTime);
										status="PASS";
										String Errormessage="";
										String NotAssignTestCaseID="";
										String NotAssignScenerio="";
										String NotAssignTestCaseDescription="";
										int columnNumber_TCID;
										int columnNumber_Scenario;
										int columnNumber_TestCaseDescription;

										utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
										Errormessage=""+SuiteName+" is not assigned to "+Employee_namecheck+" User";
										System.out.println(Errormessage);

										columnNumber_TCID						=		UtilFunction.getColumnWithCellData(fileName, sheetName, "TCID");
										columnNumber_Scenario					=		UtilFunction.getColumnWithCellData(fileName, sheetName, "Scenario");
										columnNumber_TestCaseDescription		=		UtilFunction.getColumnWithCellData(fileName, sheetName, "Test Case Description");

										NotAssignTestCaseID=UtilFunction.getCellData(fileName, sheetName, columnNumber_TCID, count);
										NotAssignScenerio=UtilFunction.getCellData(fileName, sheetName, columnNumber_Scenario, count);
										NotAssignTestCaseDescription=UtilFunction.getCellData(fileName, sheetName, columnNumber_TestCaseDescription, count);

										utilfunc.TestngReportFail(NotAssignTestCaseID, utilfunc.Actualbrw, NotAssignScenerio,ActionName,NotAssignTestCaseDescription,status,Errormessage);
										NotAssignedModuleCounter++;
										NumberOfNotAssignModule.add(SuiteName);
										*/
									
								}
								// secure messaging ends here //
								
								
								// code start here for process and questionnaire 
								else if(SuiteName.equals("ProcessQuestionnaire Assignment")){
				    					
				    					String BalNoXpath="//*[contains(@class,'table-rec-container')]//tbody//tr[1]//td[2]";
				    					try {
				    						Thread.sleep(1500);
											utilfunc.MakeElement(BalNoXpath).click();
										} catch (Exception e1) {
											System.out.println("==Unable to click on the bal no==");
										}
				    					
				    					String sidebarxpath=".//*[@id='slider-icon']";
			    						try {
			    							Thread.sleep(1500);
											utilfunc.MakeElement(sidebarxpath).click();
											Thread.sleep(3000);
										} catch (Exception e1) {
											System.out.println("==Unable to click on slider icon==");
											
										}

			    						String ProcessAndQuestionnairelinkXpath="//*[contains(@id,'right-nav')]//*[contains(text(),'Process')]";
			    						try {
			    							Thread.sleep(1500);
											utilfunc.MakeElement(ProcessAndQuestionnairelinkXpath).click();
										} catch (Exception e1) {
									
											System.out.println("==Unable to click on the process and questionnaire==");
											
										}
			    						
			    						//Step 1: Code process type
			    						
			    						startTime = System.currentTimeMillis();
										try{
										Page_flag	=	obj_CIMS_Processandquestionnaire_ProcessType.Process_Type(fileName,sheetName,count,ActionName);
										timer = utilfunc.getTimeTakenByModule(startTime);
										utilfunc.updateModuleDataForReportGeneration(SuiteName + " - Process", Employee_namecheck, timer);
										if (Page_flag)
										{
											status="PASS";
											if(utilfunc.globalerrormessage.equals(""))
											{
												utilfunc.TestngReportPass(obj_CIMS_Processandquestionnaire_ProcessType.testcaseid, utilfunc.Actualbrw, obj_CIMS_Processandquestionnaire_ProcessType.scenerio, ActionName, obj_CIMS_Processandquestionnaire_ProcessType.description, status);
											}
											else
											{
												utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Processandquestionnaire_ProcessType.testcaseid, utilfunc.Actualbrw,obj_CIMS_Processandquestionnaire_ProcessType.scenerio,ActionName,obj_CIMS_Processandquestionnaire_ProcessType.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											}
											if(passCounter==false){
												 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
												 passCounter=true;
											 }
											try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Processandquestionnaire_ProcessType.testcaseid, utilfunc.Actualbrw, obj_CIMS_Processandquestionnaire_ProcessType.scenerio, ActionName, obj_CIMS_Processandquestionnaire_ProcessType.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
										}
										else
										{
											status="FAIL";
											utilfunc.TakeScreenshot();
											utilfunc.TestngReportFail1(obj_CIMS_Processandquestionnaire_ProcessType.testcaseid, utilfunc.Actualbrw, obj_CIMS_Processandquestionnaire_ProcessType.scenerio,ActionName, obj_CIMS_Processandquestionnaire_ProcessType.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											if(failCounter==false){
					    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
					    						failCounter	= true;
				    						}
											try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Processandquestionnaire_ProcessType.testcaseid, utilfunc.Actualbrw, obj_CIMS_Processandquestionnaire_ProcessType.scenerio,ActionName, obj_CIMS_Processandquestionnaire_ProcessType.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
										}
										}catch(Exception e){
											ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
											System.out.println("Script Failed");
											utilfunc.assertion();			
											utilfunc.TakeScreenshot();
											}

			    						
			    						
				    					
				    					// Step 2
										// now call modules according to enable modules
										//																System.out.println("calling "+SuiteName+" module..");
										Thread.sleep(1500);
										startTime = System.currentTimeMillis();
										try{
										Page_flag	=	obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.Questionnaire_Assignment(fileName,sheetName,count,ActionName);
										timer = utilfunc.getTimeTakenByModule(startTime);
										utilfunc.updateModuleDataForReportGeneration(SuiteName+"-Questionnaires for Employee", Employee_namecheck, timer);
										if (Page_flag)
										{
											status="PASS";
											if(utilfunc.globalerrormessage.equals(""))
											{
												utilfunc.TestngReportPass(obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.scenerio, ActionName, obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.description, status);
											}
											else
											{
												utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.testcaseid, utilfunc.Actualbrw,obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.scenerio,ActionName,obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											}
											if(passCounter==false){
												 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
												 passCounter=true;
											 }
											try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.scenerio, ActionName, obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
										}
										else
										{
											status="FAIL";
											utilfunc.TakeScreenshot();
											utilfunc.TestngReportFail1(obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.scenerio,ActionName, obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											if(failCounter==false){
					    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
					    						failCounter	= true;
				    						}
											try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.scenerio,ActionName, obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
										}
										}catch(Exception e){
											ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
											System.out.println("Script Failed");
											utilfunc.assertion();			
											utilfunc.TakeScreenshot();
											}
										
									   // Step 3 - for questionnaire assignment for employer 
										Thread.sleep(1500);
										startTime = System.currentTimeMillis();
										try{
										Page_flag	=	obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.Employer_Questionnaire(fileName,sheetName,count,ActionName);
										timer = utilfunc.getTimeTakenByModule(startTime);
										utilfunc.updateModuleDataForReportGeneration(SuiteName+"-Questionnaires for Employer", Employee_namecheck, timer);
										if (Page_flag)
										{
											status="PASS";
											if(utilfunc.globalerrormessage.equals(""))
											{
												utilfunc.TestngReportPass(obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.scenerio, ActionName, obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.description, status);
											}
											else
											{
												utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.testcaseid, utilfunc.Actualbrw,obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.scenerio,ActionName,obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											}
											if(passCounter==false){
												 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
												 passCounter=true;
											 }
											try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.scenerio, ActionName, obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
										}
										else
										{
											status="FAIL";
											utilfunc.TakeScreenshot();
											utilfunc.TestngReportFail1(obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.scenerio,ActionName, obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											if(failCounter==false){
					    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
					    						failCounter	= true;
				    						}
											try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.scenerio,ActionName, obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
										}
										}catch(Exception e){
											ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
											System.out.println("Script Failed");
											utilfunc.assertion();			
											utilfunc.TakeScreenshot();
											}

										
									// Code End here
										
										// Step 4: Code start for contact assignment 
										Thread.sleep(1500);
										
										try{
										Page_flag	=	obj_CIMS_Regression_ProcessAndQuestionnaire_contact.Contact_Assignment(fileName,sheetName,count,ActionName,Employee_namecheck);
										timer = utilfunc.getTimeTakenByModule(startTime);
										utilfunc.updateModuleDataForReportGeneration(SuiteName+"-Bal Contact Assignment", Employee_namecheck, timer);
										if (Page_flag)
										{
											status="PASS";
											if(utilfunc.globalerrormessage.equals(""))
											{
												utilfunc.TestngReportPass(obj_CIMS_Regression_ProcessAndQuestionnaire_contact.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_ProcessAndQuestionnaire_contact.scenerio, ActionName, obj_CIMS_Regression_ProcessAndQuestionnaire_contact.description, status);
											}
											else
											{
												utilfunc.TestngReportNegativePassTestcase(obj_CIMS_Regression_ProcessAndQuestionnaire_contact.testcaseid, utilfunc.Actualbrw,obj_CIMS_Regression_ProcessAndQuestionnaire_contact.scenerio,ActionName,obj_CIMS_Regression_ProcessAndQuestionnaire_contact.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											}
											if(passCounter==false){
												 try {	obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Pass");} catch (Exception e) {}
												 passCounter=true;
											 }
											try {obj_Report_Dashboard.writeDashBoardPassReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_ProcessAndQuestionnaire_contact.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_ProcessAndQuestionnaire_contact.scenerio, ActionName, obj_CIMS_Regression_ProcessAndQuestionnaire_contact.description, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard pass report for : "+SuiteName);}
										}
										else
										{
											status="FAIL";
											utilfunc.TakeScreenshot();
											utilfunc.TestngReportFail1(obj_CIMS_Regression_ProcessAndQuestionnaire_contact.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_ProcessAndQuestionnaire_contact.scenerio,ActionName, obj_CIMS_Regression_ProcessAndQuestionnaire_contact.description, status, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);
											if(failCounter==false){
					    						obj_Report_Dashboard.writeReportHeader(RegressionSuites, sheetName,"Fail");
					    						failCounter	= true;
				    						}
											try {obj_Report_Dashboard.writeDashBoardFailReport(RegressionSuites, Employee_namecheck, obj_CIMS_Regression_ProcessAndQuestionnaire_contact.testcaseid, utilfunc.Actualbrw, obj_CIMS_Regression_ProcessAndQuestionnaire_contact.scenerio,ActionName, obj_CIMS_Regression_ProcessAndQuestionnaire_contact.description, status, timer, utilfunc.ErrorMessage2,utilfunc.ErrorMessage1,utilfunc.ErrorMessage4);} catch (Exception e) {System.out.println("unable to write dasboard fail report for : "+SuiteName);}
										}
										}catch(Exception e){
											ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
											System.out.println("Script Failed");
											utilfunc.assertion();			
											utilfunc.TakeScreenshot();
											}

										
										//code end here 
										
				    				}
									// code end here for process and questionnaire 
								
								else{
									
									try{
										Thread.sleep(3000);
										timer = utilfunc.getTimeTakenByModule(startTime);
										status="PASS";
										String Errormessage="";
										String NotAssignTestCaseID="";
										String NotAssignScenerio="";
										String NotAssignTestCaseDescription="";
										int columnNumber_TCID;
										int columnNumber_Scenario;
										int columnNumber_TestCaseDescription;

										utilfunc.updateModuleDataForReportGeneration(SuiteName, Employee_namecheck, timer);
										Errormessage=""+SuiteName+" is not assigned to "+Employee_namecheck+" User";
										System.out.println(Errormessage);

										columnNumber_TCID						=		UtilFunction.getColumnWithCellData(fileName, sheetName, "TCID");
										columnNumber_Scenario					=		UtilFunction.getColumnWithCellData(fileName, sheetName, "SCENARIO");
										columnNumber_TestCaseDescription		=		UtilFunction.getColumnWithCellData(fileName, sheetName, "Test Case Description");

										NotAssignTestCaseID=UtilFunction.getCellData(fileName, sheetName, columnNumber_TCID, count);
										NotAssignScenerio=UtilFunction.getCellData(fileName, sheetName, columnNumber_Scenario, count);
										NotAssignTestCaseDescription=UtilFunction.getCellData(fileName, sheetName, columnNumber_TestCaseDescription, count);

										utilfunc.TestngReportFail(NotAssignTestCaseID, utilfunc.Actualbrw, NotAssignScenerio,ActionName,NotAssignTestCaseDescription,status,Errormessage);
										NotAssignedModuleCounter++;
										NumberOfNotAssignModule.add(SuiteName);
									
											if(notAssignedCounter==false){
												 obj_Report_Dashboard.writeReportHeader(RegressionSuites, SuiteName,"Not Assigned");
												 notAssignedCounter=true;
											 }
											try {obj_Report_Dashboard.writeDashBoardNotAssignedReport(RegressionSuites, Employee_namecheck, NotAssignTestCaseID, utilfunc.Actualbrw, NotAssignScenerio, ActionName, NotAssignTestCaseDescription, status, timer);} catch (Exception e) {System.out.println("unable to write dasboard not assigned report for : "+SuiteName);}
											
									}catch(Exception e){
										System.out.println("");
									}
									
								}
								
							}
						}

					}
				}catch(Exception e){

				}
			}

			
			LinkedHashSet<String> lhs = new LinkedHashSet<String>();
			lhs.addAll(NumberOfNotAssignModule);
			NumberOfNotAssignModule.clear();
			NumberOfNotAssignModule.addAll(lhs);
			NotAssignedModuleCounter=NumberOfNotAssignModule.size();
			
			System.out.println("========\n========\n========");
			System.out.println("PositiveScenarioCounter : "+PositiveScenarioCounter);
			System.out.println("NegativeScenarioCounter : "+NegativeScenarioCounter);
			System.out.println("ModuleCounter : "+ModuleCounter);
			System.out.println("TotalTestCaseCounter : "+TotalTestCaseCounter);
			System.out.println("passTestCaseCounter : "+passTestCaseCounter);
			System.out.println("failTestCaseCounter : "+failTestCaseCounter);
			System.out.println("NotAssignedModuleCounter : "+NotAssignedModuleCounter);
			System.out.println("========\n========\n========");

			// adding dashboard code here..
			String PositiveScenarioCount="";
			String NegativeScenarioCount="";
			String ModuleCount="";
			String TotalTestCaseCount="";
			String FinalPositiveCount="";
			String FinalNegativeCount="";
			String NotAssignedModuleCount="";

			try{	PositiveScenarioCount			=	Integer.toString(PositiveScenarioCounter);	}catch(Exception error){}
			try{	NegativeScenarioCount			=	Integer.toString(NegativeScenarioCounter);	}catch(Exception error){}
			try{	ModuleCount						=	Integer.toString(ModuleCounter);			}catch(Exception error){}
			try{	TotalTestCaseCount				=	Integer.toString(TotalTestCaseCounter);	}catch(Exception error){}
			try{	FinalPositiveCount				=	Integer.toString(passTestCaseCounter);	}catch(Exception error){}
			try{	FinalNegativeCount				=	Integer.toString(failTestCaseCounter);	}catch(Exception error){}
			try{	NotAssignedModuleCount			=	Integer.toString(NotAssignedModuleCounter);	}catch(Exception error){}

		//	utilfunc.TestngDashBoardReport("Left Navigation",ModuleCount,TotalTestCaseCount,PositiveScenarioCount,NegativeScenarioCount,FinalPositiveCount,FinalNegativeCount,NotAssignedModuleCount);
			TotalTime = utilfunc.getTimeTakenByModule(startTotalTime);
			try{
				obj_Report_Dashboard.generateReportForSuite(RegressionSuites,ModuleCount,TotalTestCaseCount,PositiveScenarioCount,NegativeScenarioCount,
					FinalPositiveCount,FinalNegativeCount,TotalTime,NotAssignedModuleCount);
			}catch(Exception e){
				System.out.println("unable to call & generate dashboard report for regression..");
			}


		}
		catch(Exception e){
			ErrorUtil.addVerificationFailure(new Throwable("Error Occured !!"));
			System.out.println("Script Failed!!!");
			utilfunc.assertion();
			utilfunc.TakeScreenshot();
		}

	}



	// Below Methods are getters and setters for Test Parameters.	

	public String getSysDate() {
		return sysDate;
	}
	public WebDriver getDriver() {
		return webdriver;
	}
	public void setDriver(String browser) {
		this.webdriver = UtilFunction.getDriver(browser);
	}
	public void setSysDate(String sysdate) {
		this.sysDate = sysdate ;
	}
	public UtilFunction getUtilfunc() {
		return utilfunc;
	}

	public void setUtilfunc(UtilFunction utilfunc) {
		this.utilfunc = utilfunc;
	}		

	public void setobj_Project_Initiation(Project_Initiation setobj_Project_Initiation) {
		this.obj_Project_Initiation	=	setobj_Project_Initiation;	 

	}

	public void setobj_CIMS_Single_Project_Initiation(CIMS_Single_Project_Initiation setobj_CIMS_Single_Project_Initiation) {
		this.obj_CIMS_Single_Project_Initiation	=	setobj_CIMS_Single_Project_Initiation;	 

	}


	public void setobj_CIMS_Regresssion_Suite_Bulk_Initiation(CIMS_Regresssion_Suite_Bulk_Initiation setobj_CIMS_Regresssion_Suite_Bulk_Initiation) {
		this.obj_CIMS_Regresssion_Suite_Bulk_Initiation	=	setobj_CIMS_Regresssion_Suite_Bulk_Initiation;
	}

	/*public void setDriver(WebDriver driver) {
			this.driver = driver;
		}*/

	public void setobj_CIMS_Login(CIMS_Login setobj_CIMS_Login) {
		this.obj_CIMS_Login = setobj_CIMS_Login;
	}


	public void setobj_CIMS_Regression_Suite_Immigration_Status(CIMS_Regression_Suite_Immigration_Status setobj_CIMS_Regression_Suite_Immigration_Status) {
		this.obj_CIMS_Regression_Suite_Immigration_Status	=	setobj_CIMS_Regression_Suite_Immigration_Status;

	}
	public void setobj_CIMS_Immigration_Document(CIMS_Immigration_Document setobj_CIMS_Immigration_Document) {
		this.obj_CIMS_Immigration_Document	=	setobj_CIMS_Immigration_Document;
	}

	public void setobj_CIMS_Regression_Suite_Employee_Profile(CIMS_Regression_Suite_Employee_Profile setobj_CIMS_Regression_Suite_Employee_Profile) {
		this.obj_CIMS_Regression_Suite_Employee_Profile	=	setobj_CIMS_Regression_Suite_Employee_Profile;
	}

	public void setobj_CIMS_GCP_NewQuery(CIMS_GCP_NewQuery setobj_CIMS_GCP_NewQuery) {
		this.obj_CIMS_GCP_NewQuery	=	setobj_CIMS_GCP_NewQuery;
	}
	//Lokesh Append this code for "All My Tasks" on Welcome Page
	/*	public void setobj_CIMS_Regression_Suite_AllMyTasks(CIMS_Regression_Suite_AllMyTasks setobj_CIMS_Regression_Suite_AllMyTasks){
				this.obj_CIMS_Regression_Suite_AllMyTasks	=	setobj_CIMS_Regression_Suite_AllMyTasks;
			}*/
	//Lokesh Append this code for "News" on Welcome Page
	public void setobj_CIMS_Regression_Suite_News(CIMS_Regression_Suite_News setobj_CIMS_Regression_Suite_News){
		this.obj_CIMS_Regression_Suite_News	=	setobj_CIMS_Regression_Suite_News;
	}

	public void setobj_Employee_Search(Employee_Search setobj_Employee_Search){
		this.obj_Employee_Search	=	setobj_Employee_Search;
	}


	// Lokesh add these line(s) on 06-May-2016 for Advance Project search
	public void setobj_Project_Search(Project_Search setobj_Project_Search){
		this.obj_Project_Search	=	setobj_Project_Search;
	}


	// dashboard report
		public void setobj_dashboard(dashboard setobj_Report_Dashboard) {
			this.obj_Report_Dashboard = setobj_Report_Dashboard;
		}
	
		public void setobj_CIMS_Secure_Messaging(CIMS_Secure_Messaging setobj_CIMS_Secure_Messaging) {
			this.obj_CIMS_Secure_Messaging = setobj_CIMS_Secure_Messaging;
		}

		
		
		// Dharam Code start here CIMS_Regression_ProcessAndQuestionnaire_contact
		public void setobj_CIMS_Regression_Suite_Process_Questionnaire_Assignment(CIMS_Regression_Suite_Process_Questionnaire_Assignment setobj_CIMS_Regression_Suite_Process_Questionnaire_Assignment) {
			this.obj_CIMS_Regression_Suite_Process_Questionnaire_Assignment=setobj_CIMS_Regression_Suite_Process_Questionnaire_Assignment;
		}
		
		public void setobj_CIMS_Processandquestionnaire_ProcessType(CIMS_Processandquestionnaire_ProcessType setobj_CIMS_Processandquestionnaire_ProcessType) {
			this.obj_CIMS_Processandquestionnaire_ProcessType=setobj_CIMS_Processandquestionnaire_ProcessType;
		}
		
		public void setobj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment(CIMS_Regression_Suite_Emp_Questionnaire_Assignment setobj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment) {
			this.obj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment=setobj_CIMS_Regression_Suite_Emp_Questionnaire_Assignment;
		}
		
		public void setobj_CIMS_Regression_ProcessAndQuestionnaire_contact(CIMS_Regression_ProcessAndQuestionnaire_contact setobj_CIMS_Regression_ProcessAndQuestionnaire_contact) {
			this.obj_CIMS_Regression_ProcessAndQuestionnaire_contact=setobj_CIMS_Regression_ProcessAndQuestionnaire_contact;
		}
// Dharam Code End here CIMS_Regression_Suite_Emp_Questionnaire_Assignment


	//LOKESH CODE 
	public String Immigration_Status_Document(String SuiteName,String Actionname) throws InterruptedException
	{
		String suiteLink="";
		String AddNewButton=".//*[@id='local-navigation']//*[contains(@class,'btn')]//*[contains(@class,'icon-plus')]";
		if(Actionname.equalsIgnoreCase("New")){
			try{
				utilfunc.scrollToTop();//make sure that before click the add new button; same button should be in visible area.
				Thread.sleep(2000);
				utilfunc.MakeElement(AddNewButton).click();
			}catch(Exception e){
				System.out.println("Unable to find the Add Button");
			}
			suiteLink			=		".//*[@id='docs']/center//*[contains(@class,'btn') and text()='"+ SuiteName +"']";
		}
		else if(Actionname.equals("Edit") || (Actionname.equals("Delete"))){

			Thread.sleep(1500);

			// before clicking on delete icon let us expand the list...
			String LinkText		=	(SuiteName.equals("Immigration Status")) ? "Status" : "Document";
			String ListExpandXpath		=	".//*[contains(@id,'"+ LinkText +"')]/table/tbody/tr[1]/td[2]";
			Thread.sleep(1500);
			utilfunc.MakeElement(ListExpandXpath).click();
			Thread.sleep(1500);
			// now click on action button
			String ActionBtnXPath		=	".//*[contains(@id,'"+ LinkText +"')]/table/tbody/tr[2]/td//*[contains(@class,'btn-group')]//*[contains(@class,'btn')]//*[contains(@class,'icon-cog')]";
			suiteLink		=	ActionBtnXPath;
			Thread.sleep(1500);
		}			
		return suiteLink;
	}
	//LOKESH CODE


}

